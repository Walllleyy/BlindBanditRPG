"""
Configuration settings for BlindBanditRPG.
"""
import os

# Command prefix for the bot
COMMAND_PREFIX = "!"

# File paths
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
PLAYERS_FILE = os.path.join(DATA_DIR, "players.json")

# Game balance settings
BASE_HP = 100
HP_PER_LEVEL = 5
LEVEL_UP_XP_MULTIPLIER = 100
DAMAGE_BONUS_PER_LEVEL = 2

# Adventure settings
EXPLORE_BATTLE_CHANCE = 0.25  # 1 in 4 chance
ADVENTURE_BATTLE_CHANCE = 0.5  # 1 in 2 chance

# Available classes
AVAILABLE_CLASSES = [
    "Warrior", 
    "Spellblade", 
    "Rogue", 
    "Hunter", 
    "Paladin", 
    "Gunslinger", 
    "Elementalist",
    "Necromancer",
    "Berserker",
    "Druid",
    "Monk",
    "Alchemist",
    "Witch",
    "Fairy"
]

# Resource gathering rewards
GATHERING_REWARDS = {
    "common": {
        "mine": ["Iron Ore", "Stone", "Coal"],
        "chop": ["Wood", "Sap", "Twigs"],
        "forage": ["Herbs", "Berries", "Mushrooms"]
    },
    "rare": {
        "mine": ["Silver Ore", "Crystal Shard"],
        "chop": ["Rare Bark", "Enchanted Vine"],
        "forage": ["Glowcap", "Fairy Dust"]
    },
    "rare_chance": 1/6  # 1 in 6 chance for rare drops
}

# Combat settings
BASE_PLAYER_DAMAGE_RANGE = (8, 12)
CRIT_CHANCE = 0.1  # 10% chance for critical hits
CRIT_MULTIPLIER = 1.5  # 50% bonus damage