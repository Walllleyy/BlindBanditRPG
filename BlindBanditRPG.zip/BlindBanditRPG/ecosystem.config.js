echo module.exports = { > ecosystem.config.js
echo   apps: [{ >> ecosystem.config.js
echo     name: "BlindBanditRPG", >> ecosystem.config.js
echo     script: "bot.py", >> ecosystem.config.js
echo     interpreter: "D:\\BGW Games\\BlindBanditRPG\\venv\\Scripts\\python.exe", >> ecosystem.config.js
echo     autorestart: true, >> ecosystem.config.js
echo     watch: false, >> ecosystem.config.js
echo     windowsHide: true >> ecosystem.config.js
echo   }] >> ecosystem.config.js
echo }; >> ecosystem.config.js