"""
Data management utilities for BlindBanditRPG.
Handles loading and saving game data.
"""
import json
import os
from config import PLAYERS_FILE

def load_player_data():
    """
    Load player data from the JSON file.
    
    Returns:
        dict: A dictionary containing player data
    """
    try:
        if os.path.exists(PLAYERS_FILE):
            with open(PLAYERS_FILE, "r") as f:
                return json.load(f)
        else:
            # Return empty dict if file doesn't exist
            return {}
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")
        # If file is corrupted, return empty dict
        return {}
    except Exception as e:
        print(f"Error loading player data: {e}")
        return {}

def save_player_data(data):
    """
    Save player data to the JSON file.
    
    Args:
        data (dict): The player data to save
    
    Returns:
        bool: True if save was successful, False otherwise
    """
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(PLAYERS_FILE), exist_ok=True)
        
        with open(PLAYERS_FILE, "w") as f:
            json.dump(data, f, indent=4)
        return True
    except Exception as e:
        print(f"Error saving player data: {e}")
        return False

def get_player(user_id):
    """
    Get a player's data by user ID.
    
    Args:
        user_id (str): The Discord user ID
    
    Returns:
        dict: The player's data, or None if not found
    """
    players = load_player_data()
    return players.get(str(user_id))

def update_player(user_id, data):
    """
    Update a specific player's data.
    
    Args:
        user_id (str): The Discord user ID
        data (dict): The player data to update
    
    Returns:
        bool: True if update was successful, False otherwise
    """
    players = load_player_data()
    players[str(user_id)] = data
    return save_player_data(players)

def player_exists(user_id):
    """
    Check if a player exists in the database.
    
    Args:
        user_id (str): The Discord user ID
    
    Returns:
        bool: True if player exists, False otherwise
    """
    players = load_player_data()
    return str(user_id) in players