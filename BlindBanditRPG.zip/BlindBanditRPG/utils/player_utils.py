"""
Player utilities for BlindBanditRPG.
Handles player actions, progression, and inventory.
"""
import random
from config import BASE_HP, HP_PER_LEVEL, LEVEL_UP_XP_MULTIPLIER, DAMAGE_BONUS_PER_LEVEL

def create_new_player(user_id, username):
    """
    Create a new player with default values.
    
    Args:
        user_id (str): The Discord user ID
        username (str): The Discord username
    
    Returns:
        dict: The newly created player data
    """
    player = {
        "name": username,
        "class": None,
        "level": 1,
        "xp": 0,
        "hp": BASE_HP,
        "gear": {
            "weapon": "None",
            "armor": "Cloth Shirt",
            "condition": "Restored",
            "damage_bonus": 0
        },
        "inventory": {},
        "gold": 10,  # Starting gold
        "stats": {  # Default stats
            "strength": 3,
            "agility": 3, 
            "intelligence": 3,
            "vitality": 3
        },
        "skill_points": 0
    }
    return player

def check_level_up(player):
    """
    Check if a player has enough XP to level up and apply the level up.
    
    Args:
        player (dict): The player data
    
    Returns:
        bool: True if player leveled up, False otherwise
    """
    xp = player["xp"]
    level = player["level"]
    next_level_xp = level * LEVEL_UP_XP_MULTIPLIER

    if xp >= next_level_xp:
        from models.player import apply_level_up
        apply_level_up(player)
        return True
    return False

def add_to_inventory(player, items):
    """
    Add items to a player's inventory.
    
    Args:
        player (dict): The player data
        items (list): List of items to add
    """
    if "inventory" not in player:
        player["inventory"] = {}
    
    for item in items:
        if item in player["inventory"]:
            player["inventory"][item] += 1
        else:
            player["inventory"][item] = 1

def show_inventory(player):
    """
    Get a formatted string of a player's inventory.
    
    Args:
        player (dict): The player data
    
    Returns:
        str: Formatted inventory string
    """
    if "inventory" not in player or not player["inventory"]:
        return "Your inventory is empty."
    
    return "\n".join(f"{item}: {qty}" for item, qty in player["inventory"].items())

def calculate_damage(player, is_critical=None):
    """
    Calculate damage for a player attack.
    
    Args:
        player (dict): The player data
        is_critical (bool, optional): Force critical hit state
    
    Returns:
        tuple: (damage_amount, is_critical_hit)
    """
    base_min, base_max = 8, 12
    bonus = player["gear"].get("damage_bonus", 0)
    
    # Determine if attack is critical
    if is_critical is None:
        # Use the player's crit chance from stats if available
        from models.player import calculate_crit_chance
        crit_chance = calculate_crit_chance(player) / 100  # Convert from % to decimal
        is_critical = random.random() < crit_chance
    
    # Calculate base damage
    damage = random.randint(base_min, base_max + bonus)
    
    # Apply critical multiplier if applicable
    if is_critical:
        damage = int(damage * 1.5)
    
    return damage, is_critical

def restore_hp(player):
    """
    Restore a player's HP to maximum.
    
    Args:
        player (dict): The player data
    """
    from models.player import calculate_max_hp
    player["hp"] = calculate_max_hp(player)

def repair_gear(player):
    """
    Repair a player's gear.
    
    Args:
        player (dict): The player data
    """
    if "gear" in player:
        player["gear"]["condition"] = "Restored"

def equip_item(player, item, slot=None):
    """
    Equip an item from inventory to a gear slot.
    
    Args:
        player (dict): The player data
        item (str): The item to equip
        slot (str, optional): The slot to equip to. If None, auto-detect
    
    Returns:
        tuple: (success, message)
    """
    inv = player.get("inventory", {})
    
    # Check if player has the item
    if item not in inv or inv[item] < 1:
        return False, "You don't have that item."
    
    # Auto-detect slot if not specified
    if slot is None:
        if any(word in item.lower() for word in ["blade", "sword", "axe", "staff", "wand"]):
            slot = "weapon"
        else:
            slot = "armor"
    
    # Get the old item
    old_item = player["gear"].get(slot, "None")
    
    # Equip the new item
    player["gear"][slot] = item
    player["inventory"][item] -= 1
    
    # Remove item from inventory if zero
    if player["inventory"][item] <= 0:
        del player["inventory"][item]
    
    # Add old item to inventory if it's not "None"
    if old_item and old_item != "None":
        player["inventory"][old_item] = player["inventory"].get(old_item, 0) + 1
    
    # Recalculate stats after equipping new item
    from models.player import calculate_damage_bonus
    player["gear"]["damage_bonus"] = calculate_damage_bonus(player)
    
    return True, f"You equipped **{item}** in the {slot} slot."