"""
Utility functions to update the player model to support new features.
This file will help transition existing player data to support housing, crafting, and achievements.
"""
from utils.data_manager import load_player_data, save_player_data

def update_player_models():
    """Update all player data to support new features"""
    # Load all player data
    all_players = load_player_data()
    updated_players = False
    
    for user_id, player in all_players.items():
        # Skip invalid player data
        if not isinstance(player, dict) or "name" not in player:
            continue
        
        player_updated = False
        
        # Add house if missing
        if "house" not in player:
            player["house"] = {
                "level": 0,
                "last_gold_claim": 0
            }
            player_updated = True
        
        # Add gold if missing
        if "gold" not in player:
            player["gold"] = 10  # Start with a small amount
            player_updated = True
        
        # Add achievements if missing
        if "achievements" not in player:
            player["achievements"] = {}
            player_updated = True
        
        # Add stats tracking if missing
        if "stats" not in player:
            player["stats"] = {
                "battles_won": 0,
                "resources_gathered": 0,
                "items_crafted": 0
            }
            player_updated = True
        else:
            # Add individual stat trackers if missing
            stats_updated = False
            for stat in ["battles_won", "resources_gathered", "items_crafted"]:
                if stat not in player["stats"]:
                    player["stats"][stat] = 0
                    stats_updated = True
            
            if stats_updated:
                player_updated = True
        
        # Add regions_visited if missing
        if "regions_visited" not in player:
            player["regions_visited"] = []
            player_updated = True
        
        # Update the player if changes were made
        if player_updated:
            all_players[user_id] = player
            updated_players = True
    
    # Save all player data if changes were made
    if updated_players:
        save_player_data(all_players)
        return True
    
    return False

def increment_stat(player, stat_name, amount=1):
    """
    Increment a stat counter for a player
    
    Args:
        player (dict): Player data
        stat_name (str): Name of the stat to increment
        amount (int): Amount to increment by (default: 1)
    
    Returns:
        dict: Updated player data
    """
    # Initialize stats if not present
    if "stats" not in player:
        player["stats"] = {}
    
    # Initialize specific stat if not present
    if stat_name not in player["stats"]:
        player["stats"][stat_name] = 0
    
    # Increment stat
    player["stats"][stat_name] += amount
    
    return player

def track_region_visit(player, region):
    """
    Track that a player visited a region
    
    Args:
        player (dict): Player data
        region (str): Name of the region visited
    
    Returns:
        dict: Updated player data
        bool: True if this is the first time visiting the region, False otherwise
    """
    # Initialize regions_visited if not present
    if "regions_visited" not in player:
        player["regions_visited"] = []
    
    # Check if this region has been visited before
    if region not in player["regions_visited"]:
        player["regions_visited"].append(region)
        return player, True
    
    return player, False

def get_house_bonuses(player):
    """
    Get the bonuses provided by a player's house
    
    Args:
        player (dict): Player data
    
    Returns:
        dict: House bonuses (rest_bonus, storage_bonus, gold_per_day)
    """
    from cogs.housing import HOUSE_LEVELS
    
    # Initialize house if not present
    if "house" not in player:
        player["house"] = {
            "level": 0,
            "last_gold_claim": 0
        }
    
    house_level = player["house"]["level"]
    house_info = HOUSE_LEVELS.get(house_level, HOUSE_LEVELS[0])
    
    return {
        "rest_bonus": house_info["rest_bonus"],
        "storage_bonus": house_info["storage_bonus"],
        "gold_per_day": house_info["gold_per_day"]
    }

def has_achievement(player, achievement_id):
    """
    Check if a player has a specific achievement
    
    Args:
        player (dict): Player data
        achievement_id (str): ID of the achievement to check
    
    Returns:
        bool: True if the player has the achievement, False otherwise
    """
    return achievement_id in player.get("achievements", {})

def get_crafting_tools_bonus(player):
    """
    Get crafting bonus based on tools in inventory
    
    Args:
        player (dict): Player data
    
    Returns:
        int: Crafting bonus
    """
    crafting_bonus = 0
    
    # Check for Crafting Tools achievement reward
    if has_achievement(player, "master_crafter"):
        crafting_bonus += 1
    
    return crafting_bonus

def get_gathering_bonus(player, resource_type):
    """
    Get gathering bonus for a specific resource type
    
    Args:
        player (dict): Player data
        resource_type (str): Type of resource (wood, ore, herbs)
    
    Returns:
        int: Gathering bonus
    """
    gathering_bonus = 0
    
    # Check for special tools
    inventory = player.get("inventory", {})
    
    if resource_type == "wood" and inventory.get("Stone Axe", 0) > 0:
        gathering_bonus += 2
    
    elif resource_type == "ore" and inventory.get("Iron Pickaxe", 0) > 0:
        gathering_bonus += 2
    
    elif resource_type == "herbs" and inventory.get("Herb Bag", 0) > 0:
        gathering_bonus += 2
    
    # Add achievement bonuses
    if has_achievement(player, "resource_gatherer"):
        gathering_bonus += 1
    
    if has_achievement(player, "master_gatherer"):
        gathering_bonus += 1
    
    return gathering_bonus