"""
Character classes for BlindBanditRPG.
Defines class attributes, abilities, and progression.
"""

# Base class definitions
CLASSES = {
    # Original Classes
    "Warrior": {
        "description": "Masters of close combat who rely on strength and heavy armor.",
        "starting_weapon": "Rusty Warrior Blade",
        "abilities": {
            "Battle Cry": {
                "level": 3,
                "description": "Increase damage by 20% for 3 turns",
                "cooldown": 5
            },
            "Shield Bash": {
                "level": 5,
                "description": "Stun enemy for 1 turn and deal damage",
                "cooldown": 4
            }
        },
        "stat_growth": {
            "strength": 1.2,
            "agility": 0.8,
            "intelligence": 0.6,
            "vitality": 1.3
        }
    },
    "Spellblade": {
        "description": "Hybrid fighters who blend swordplay with arcane magic.",
        "starting_weapon": "Rusty Spellblade Blade",
        "abilities": {
            "Arcane Strike": {
                "level": 3,
                "description": "Deal additional magic damage on hit",
                "cooldown": 3
            },
            "Spell Shield": {
                "level": 5,
                "description": "Reduce incoming damage by 30% for 2 turns",
                "cooldown": 5
            }
        },
        "stat_growth": {
            "strength": 1.0,
            "agility": 0.9,
            "intelligence": 1.2,
            "vitality": 0.9
        }
    },
    "Rogue": {
        "description": "Agile fighters who specialize in critical strikes and evasion.",
        "starting_weapon": "Rusty Rogue Blade",
        "abilities": {
            "Backstab": {
                "level": 3,
                "description": "Guaranteed critical hit if used first in battle",
                "cooldown": 4
            },
            "Smoke Bomb": {
                "level": 5,
                "description": "50% chance to dodge all attacks for 2 turns",
                "cooldown": 6
            }
        },
        "stat_growth": {
            "strength": 0.9,
            "agility": 1.4,
            "intelligence": 0.8,
            "vitality": 0.7
        }
    },
    "Hunter": {
        "description": "Skilled trackers who excel at taking down beasts.",
        "starting_weapon": "Rusty Hunter Blade",
        "abilities": {
            "Aimed Shot": {
                "level": 3,
                "description": "Increased damage against beasts and monsters",
                "cooldown": 3
            },
            "Trap": {
                "level": 5,
                "description": "50% chance to prevent enemy from attacking for 1 turn",
                "cooldown": 5
            }
        },
        "stat_growth": {
            "strength": 1.0,
            "agility": 1.2,
            "intelligence": 0.8,
            "vitality": 1.0
        }
    },
    "Paladin": {
        "description": "Holy warriors who can heal themselves and smite evil.",
        "starting_weapon": "Rusty Paladin Blade",
        "abilities": {
            "Divine Shield": {
                "level": 3,
                "description": "Absorb next attack completely",
                "cooldown": 6
            },
            "Healing Light": {
                "level": 5,
                "description": "Heal 30% of max HP",
                "cooldown": 7
            }
        },
        "stat_growth": {
            "strength": 1.1,
            "agility": 0.7,
            "intelligence": 1.0,
            "vitality": 1.2
        }
    },
    "Gunslinger": {
        "description": "Masters of firearms who deal high damage from a distance.",
        "starting_weapon": "Rusty Gunslinger Blade",
        "abilities": {
            "Quickdraw": {
                "level": 3,
                "description": "Attack first in battle, regardless of agility",
                "cooldown": 5
            },
            "Barrage": {
                "level": 5,
                "description": "Fire multiple shots, dealing 3x normal damage",
                "cooldown": 8
            }
        },
        "stat_growth": {
            "strength": 0.9,
            "agility": 1.3,
            "intelligence": 0.8,
            "vitality": 0.8
        }
    },
    "Elementalist": {
        "description": "Mages who harness elemental forces to devastate foes.",
        "starting_weapon": "Rusty Elementalist Blade",
        "abilities": {
            "Elemental Surge": {
                "level": 3,
                "description": "Deal damage based on intelligence rather than strength",
                "cooldown": 3
            },
            "Elemental Shield": {
                "level": 5,
                "description": "Create a shield that reflects 50% of damage back to enemy",
                "cooldown": 6
            }
        },
        "stat_growth": {
            "strength": 0.6,
            "agility": 0.8,
            "intelligence": 1.5,
            "vitality": 0.8
        }
    },
    
    # NEW CLASSES
    "Necromancer": {
        "description": "Dark mages who command the undead and drain life force.",
        "starting_weapon": "Bone Staff",
        "abilities": {
            "Soul Drain": {
                "level": 3,
                "description": "Steal 15% of enemy's HP and add it to your own",
                "cooldown": 4
            },
            "Raise Minion": {
                "level": 5,
                "description": "Summon an undead minion to absorb the next attack",
                "cooldown": 7
            }
        },
        "stat_growth": {
            "strength": 0.7,
            "agility": 0.8,
            "intelligence": 1.4,
            "vitality": 0.9
        }
    },
    "Berserker": {
        "description": "Wild warriors who gain power as they take damage.",
        "starting_weapon": "Twin Hand Axes",
        "abilities": {
            "Rage": {
                "level": 3,
                "description": "Damage increases as HP decreases (up to 50% bonus)",
                "cooldown": 0  # Passive ability
            },
            "Bloodlust": {
                "level": 5,
                "description": "Next 3 attacks have 25% increased damage and 15% increased crit chance",
                "cooldown": 6
            }
        },
        "stat_growth": {
            "strength": 1.4,
            "agility": 1.0,
            "intelligence": 0.5,
            "vitality": 1.0
        }
    },
    "Druid": {
        "description": "Nature guardians who can shape-shift and control plants.",
        "starting_weapon": "Gnarled Staff",
        "abilities": {
            "Nature's Touch": {
                "level": 3,
                "description": "Heal 20% HP and cleanse negative effects",
                "cooldown": 5
            },
            "Beast Form": {
                "level": 5,
                "description": "Transform into a beast for 3 turns, increasing damage by 40%",
                "cooldown": 8
            }
        },
        "stat_growth": {
            "strength": 0.9,
            "agility": 1.0,
            "intelligence": 1.2,
            "vitality": 1.1
        }
    },
    "Monk": {
        "description": "Unarmed fighters who harness inner energy for powerful strikes.",
        "starting_weapon": "Training Wraps",
        "abilities": {
            "Focused Strike": {
                "level": 3,
                "description": "Guaranteed hit that bypasses enemy defenses",
                "cooldown": 4
            },
            "Meditation": {
                "level": 5,
                "description": "Skip a turn to heal 25% HP and increase next attack damage by 50%",
                "cooldown": 6
            }
        },
        "stat_growth": {
            "strength": 1.1,
            "agility": 1.2,
            "intelligence": 1.0,
            "vitality": 0.9
        }
    },
    "Alchemist": {
        "description": "Masters of potions who use concoctions to gain advantages in battle.",
        "starting_weapon": "Glass Dagger",
        "abilities": {
            "Quick Potion": {
                "level": 3,
                "description": "Use a random potion with beneficial effects",
                "cooldown": 3
            },
            "Explosive Flask": {
                "level": 5,
                "description": "Throw an explosive potion dealing area damage",
                "cooldown": 5
            }
        },
        "stat_growth": {
            "strength": 0.8,
            "agility": 1.1,
            "intelligence": 1.3,
            "vitality": 0.8
        }
    },
    "Witch": {
        "description": "Practitioners of ancient magic who specialize in curses and hexes.",
        "starting_weapon": "Enchanted Broom",
        "abilities": {
            "Hex": {
                "level": 3,
                "description": "Curse an enemy to take 10% more damage for 3 turns",
                "cooldown": 4
            },
            "Familiar Summon": {
                "level": 5,
                "description": "Summon a magical familiar that attacks independently for 3 turns",
                "cooldown": 7
            }
        },
        "stat_growth": {
            "strength": 0.6,
            "agility": 0.9,
            "intelligence": 1.5,
            "vitality": 0.8
        }
    },
    "Fairy": {
        "description": "Tiny magical beings with powerful nature magic and healing abilities.",
        "starting_weapon": "Glowing Wand",
        "abilities": {
            "Pixie Dust": {
                "level": 3,
                "description": "Sprinkle magic dust that has a 30% chance to put the enemy to sleep for 1 turn",
                "cooldown": 4
            },
            "Nature's Blessing": {
                "level": 5,
                "description": "Heal 20% HP and increase all stats by 10% for 3 turns",
                "cooldown": 6
            }
        },
        "stat_growth": {
            "strength": 0.7,
            "agility": 1.3,
            "intelligence": 1.2,
            "vitality": 0.8
        }
    }
}

def get_class_description(class_name):
    """Get description for a class"""
    if class_name in CLASSES:
        return CLASSES[class_name]["description"]
    return "Unknown class"

def get_class_abilities(class_name):
    """Get abilities for a class"""
    if class_name in CLASSES:
        return CLASSES[class_name]["abilities"]
    return {}

def get_starting_weapon(class_name):
    """Get starting weapon for a class"""
    if class_name in CLASSES:
        return CLASSES[class_name]["starting_weapon"]
    return "Rusty Blade"

def get_unlocked_abilities(class_name, level):
    """Get abilities unlocked for a class at current level"""
    if class_name not in CLASSES:
        return []
    
    unlocked = []
    for ability_name, ability_data in CLASSES[class_name]["abilities"].items():
        if ability_data["level"] <= level:
            unlocked.append({
                "name": ability_name,
                "description": ability_data["description"],
                "cooldown": ability_data["cooldown"],
                "level": ability_data["level"]
            })
    
    return unlocked

def get_all_class_names():
    """Get list of all available class names"""
    return list(CLASSES.keys())