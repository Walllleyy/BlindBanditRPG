"""
Boss encounters for BlindBanditRPG.
Defines boss monsters, their stats, abilities, and loot tables.
"""
import random

# Boss definitions
BOSSES = {
    "The Ancient Treant": {
        "level": 5,
        "hp": 200,
        "damage": (15, 25),
        "region": "forest",
        "abilities": [
            {
                "name": "Root Grasp",
                "description": "Entangles the player, preventing dodge for 2 turns",
                "effect": "no_dodge",
                "duration": 2,
                "chance": 0.3
            },
            {
                "name": "Healing Sap",
                "description": "Heals 10% of max HP",
                "effect": "heal",
                "amount": 0.1,
                "chance": 0.2
            }
        ],
        "flavor": "A massive treant, ancient as the forest itself, blocks your path. Its bark creaks as it turns to face you...",
        "defeat_text": "The Ancient Treant groans as it falls, its branches withering as it returns to the earth.",
        "victory_text": "The Ancient Treant's roots entangle you completely. You are dragged beneath the soil...",
        "loot": [
            "Ancient Heartwood",
            "Enchanted Amber",
            "Treant's Bark Shield",
            "Nature's Essence"
        ],
        "xp_reward": 150,
        "gold_reward": 100
    },
    
    "Bog Queen": {
        "level": 8,
        "hp": 300,
        "damage": (20, 30),
        "region": "swamp",
        "abilities": [
            {
                "name": "Toxic Spray",
                "description": "Poisons the player, dealing damage over time for 3 turns",
                "effect": "poison",
                "damage": 10,
                "duration": 3,
                "chance": 0.4
            },
            {
                "name": "Summon Leeches",
                "description": "Summons leeches that heal the Bog Queen for damage dealt",
                "effect": "life_steal",
                "amount": 0.5,  # 50% of damage dealt is healed
                "duration": 2,
                "chance": 0.25
            }
        ],
        "flavor": "The murky waters part to reveal a grotesque figure. The Bog Queen rises, adorned with rotting vegetation and writhing leeches...",
        "defeat_text": "The Bog Queen shrieks as she dissolves into the swamp, leaving only bubbling mud behind.",
        "victory_text": "The Bog Queen drags you into the depths of her murky domain. The swamp claims another victim...",
        "loot": [
            "Crown of the Bog",
            "Leech-Hide Cloak",
            "Toxic Blade",
            "Swamp Pearl"
        ],
        "xp_reward": 200,
        "gold_reward": 150
    },
    
    "The Dune Tyrant": {
        "level": 12,
        "hp": 400,
        "damage": (25, 40),
        "region": "wasteland",
        "abilities": [
            {
                "name": "Sandstorm",
                "description": "Creates a sandstorm, reducing player accuracy for 3 turns",
                "effect": "reduce_accuracy",
                "amount": 0.3,  # 30% reduction
                "duration": 3,
                "chance": 0.35
            },
            {
                "name": "Burrow",
                "description": "Burrows underground, avoiding the next attack completely",
                "effect": "invulnerable",
                "duration": 1,
                "chance": 0.2
            }
        ],
        "flavor": "The sand shifts beneath your feet as an enormous scorpion-like creature emerges. The Dune Tyrant's pincers click menacingly...",
        "defeat_text": "With a final screech, the Dune Tyrant collapses. Its exoskeleton cracks open as it dissolves into the sand.",
        "victory_text": "The Dune Tyrant's stinger finds its mark. Your vision blurs as venom courses through your veins...",
        "loot": [
            "Tyrant's Pincer",
            "Desert Venom Vial",
            "Sandsilk Wrap",
            "Dune Tyrant Carapace"
        ],
        "xp_reward": 250,
        "gold_reward": 200
    },
    
    "The Witch of the Woods": {
        "level": 7,
        "hp": 250,
        "damage": (18, 28),
        "region": "forest",
        "abilities": [
            {
                "name": "Curse",
                "description": "Curses the player, reducing all stats for 3 turns",
                "effect": "curse",
                "amount": 0.2,  # 20% reduction
                "duration": 3,
                "chance": 0.3
            },
            {
                "name": "Illusory Double",
                "description": "Creates an illusion that may absorb the next attack",
                "effect": "illusion",
                "chance": 0.25
            }
        ],
        "flavor": "A crooked hut comes into view. The Witch of the Woods emerges, her eyes gleaming with ancient malice...",
        "defeat_text": "The witch shrieks as she fades away, leaving behind only a pile of tattered robes.",
        "victory_text": "The witch's curse takes hold. You feel your body turning to wood as you become another forest statue...",
        "loot": [
            "Witch's Grimoire",
            "Enchanted Broomstick",
            "Potion of Unmaking",
            "Crystal Ball Fragment"
        ],
        "xp_reward": 180,
        "gold_reward": 120
    },
    
    "The Frost Wyrm": {
        "level": 15,
        "hp": 500,
        "damage": (30, 45),
        "region": "mountain",  # New region
        "abilities": [
            {
                "name": "Ice Breath",
                "description": "Breathes freezing ice, dealing high damage",
                "effect": "ice_damage",
                "damage": 40,
                "chance": 0.3
            },
            {
                "name": "Glacial Armor",
                "description": "Forms ice armor, reducing incoming damage",
                "effect": "damage_reduction",
                "amount": 0.4,  # 40% reduction
                "duration": 2,
                "chance": 0.25
            }
        ],
        "flavor": "The mountain peak cracks open to reveal a massive serpentine dragon. The Frost Wyrm's breath turns the air to ice around you...",
        "defeat_text": "The Frost Wyrm roars one final time before crashing to the ground, its body dissolving into a shower of ice crystals.",
        "victory_text": "The Frost Wyrm's icy breath engulfs you. Your body freezes solid, becoming another trophy in its lair...",
        "loot": [
            "Wyrm Scale Armor",
            "Frostbite Blade",
            "Dragon's Tooth",
            "Frozen Heart"
        ],
        "xp_reward": 300,
        "gold_reward": 250
    }
}

# Define boss spawning chances per region
REGION_BOSS_CHANCES = {
    "forest": {
        "The Ancient Treant": 0.6,
        "The Witch of the Woods": 0.4
    },
    "swamp": {
        "Bog Queen": 1.0  # 100% chance if a boss spawns in swamp
    },
    "wasteland": {
        "The Dune Tyrant": 1.0
    },
    "mountain": {
        "The Frost Wyrm": 1.0
    }
}

def get_random_boss(region=None):
    """
    Get a random boss, optionally from a specific region.
    
    Args:
        region (str, optional): Region to get boss from
        
    Returns:
        str: Boss name
    """
    if region and region in REGION_BOSS_CHANCES:
        # Get boss based on region weights
        boss_weights = REGION_BOSS_CHANCES[region]
        boss_names = list(boss_weights.keys())
        weights = list(boss_weights.values())
        
        # Normalize weights if they don't sum to 1
        weight_sum = sum(weights)
        if weight_sum != 1:
            weights = [w / weight_sum for w in weights]
            
        # Choose a boss based on weights
        return random.choices(boss_names, weights=weights, k=1)[0]
    else:
        # Return any random boss
        return random.choice(list(BOSSES.keys()))

def get_boss_stats(boss_name):
    """
    Get stats for a boss.
    
    Args:
        boss_name (str): The name of the boss
        
    Returns:
        dict: Boss stats or None if not found
    """
    return BOSSES.get(boss_name)

def roll_for_boss_ability(boss, turn_number):
    """
    Check if a boss should use a special ability on this turn.
    
    Args:
        boss (dict): Boss data
        turn_number (int): Current turn number
        
    Returns:
        dict or None: Ability data if an ability should be used, None otherwise
    """
    # Get boss abilities
    abilities = boss.get("abilities", [])
    if not abilities:
        return None
    
    # Check each ability to see if it should trigger
    for ability in abilities:
        # Some abilities may have cooldowns or conditions
        chance = ability.get("chance", 0.0)
        
        # Roll chance
        if random.random() < chance:
            return ability
    
    return None

def get_boss_loot(boss_name, count=1):
    """
    Get random loot from a boss.
    
    Args:
        boss_name (str): The boss name
        count (int): Number of loot items to get
        
    Returns:
        list: List of loot items
    """
    boss = get_boss_stats(boss_name)
    if not boss or "loot" not in boss:
        return ["Mysterious Item"]
    
    # Get random items from loot table
    loot_table = boss["loot"]
    return random.sample(loot_table, min(count, len(loot_table)))