"""
World data for BlindBanditRPG.
Contains regions, monsters, and exploration data.
"""
import random
from config import GATHERING_REWARDS

# Region definitions with flavor text and monsters
REGIONS = {
    "forest": {
        "flavor": [
            "You step into a dense, mossy forest...",
            "Birds scatter as you crunch over dead leaves...",
            "The canopy above blocks most of the sunlight..."
        ],
        "mobs": ["Wolf", "Forest Bandit", "Entling"]
    },
    "swamp": {
        "flavor": [
            "You slosh through ankle-deep muck...",
            "A sulfuric stench burns your nose...",
            "You hear a splash nearby. Was that a frog... or something worse?"
        ],
        "mobs": ["Swamp Lurker", "Bog Witch", "Leech King"]
    },
    "wasteland": {
        "flavor": [
            "The air is dry and full of grit...",
            "Broken relics dot the barren landscape...",
            "A dust storm brews in the distance..."
        ],
        "mobs": ["Sand Raider", "Ash Beast", "Wraith"]
    }
}

# Enemy details for combat
ENEMIES = {
    # Forest enemies
    "Wolf": {
        "hp": 30, 
        "damage": (5, 10), 
        "flavor": "A snarling wolf lunges at you!",
        "region": "forest",
        "loot": ["Wolf Fang", "Wolf Pelt", "Canine Tooth"]
    },
    "Forest Bandit": {
        "hp": 40, 
        "damage": (6, 12), 
        "flavor": "A bandit ambushes you from the trees!",
        "region": "forest",
        "loot": ["Bandit Mask", "Stolen Coin", "Leather Scraps"]
    },
    "Entling": {
        "hp": 50, 
        "damage": (4, 9), 
        "flavor": "The ground shakes as an Entling approaches!",
        "region": "forest",
        "loot": ["Living Wood", "Vibrant Leaf", "Ancient Sap"]
    },
    
    # Swamp enemies
    "Swamp Lurker": {
        "hp": 45, 
        "damage": (7, 13), 
        "flavor": "A Swamp Lurker slithers toward you!",
        "region": "swamp",
        "loot": ["Murky Scale", "Poison Gland", "Lurker Eye"]
    },
    "Bog Witch": {
        "hp": 60, 
        "damage": (9, 14), 
        "flavor": "The Bog Witch cackles as she casts a hex!",
        "region": "swamp",
        "loot": ["Witch's Staff", "Hex Charm", "Cursed Cloth"]
    },
    "Leech King": {
        "hp": 80, 
        "damage": (6, 16), 
        "flavor": "The Leech King oozes into view!",
        "region": "swamp",
        "loot": ["Royal Slime", "Blood Crystal", "Leech Crown"]
    },
    
    # Wasteland enemies
    "Sand Raider": {
        "hp": 50, 
        "damage": (8, 12), 
        "flavor": "A Sand Raider rushes with dual blades!",
        "region": "wasteland",
        "loot": ["Raider Blade", "Desert Scarf", "Scrap Metal"]
    },
    "Ash Beast": {
        "hp": 70, 
        "damage": (10, 15), 
        "flavor": "An Ash Beast charges, cloaked in smoke!",
        "region": "wasteland",
        "loot": ["Smoldering Hide", "Ash Horn", "Ember Essence"]
    },
    "Wraith": {
        "hp": 60, 
        "damage": (12, 18), 
        "flavor": "A chilling Wraith phases toward you!",
        "region": "wasteland",
        "loot": ["Ethereal Wisp", "Phantom Cloth", "Soul Shard"]
    }
}

# Powerful adventure enemies
ADVENTURE_ENEMIES = {
    "Cave Troll": {
        "hp": 90, 
        "damage": (12, 20), 
        "flavor": "A Cave Troll smashes through the rocks!",
        "loot": ["Troll Tusk", "Giant Club", "Rugged Hide"]
    },
    "Blood Wolf": {
        "hp": 75, 
        "damage": (10, 16), 
        "flavor": "A Blood Wolf howls and leaps from the shadows!",
        "loot": ["Blood-Soaked Fang", "Alpha Pelt", "Feral Claw"]
    },
    "Bone Knight": {
        "hp": 85, 
        "damage": (11, 18), 
        "flavor": "A Bone Knight draws a cursed blade!",
        "loot": ["Cursed Sword", "Skeletal Armor", "Death Essence"]
    }
}

def get_random_flavor_text(region):
    """
    Get random flavor text for a region.
    
    Args:
        region (str): The region name
        
    Returns:
        str: A random flavor text for the region
    """
    if region in REGIONS:
        return random.choice(REGIONS[region]["flavor"])
    return "You explore the area..."

def get_random_enemy(region):
    """
    Get a random enemy for a region.
    
    Args:
        region (str): The region name
        
    Returns:
        str: Name of a random enemy from the region
    """
    if region in REGIONS:
        return random.choice(REGIONS[region]["mobs"])
    
    # Fallback to a random enemy if region not found
    return random.choice(list(ENEMIES.keys()))

def get_random_adventure_enemy():
    """
    Get a random powerful enemy for adventures.
    
    Returns:
        str: Name of a random adventure enemy
    """
    return random.choice(list(ADVENTURE_ENEMIES.keys()))

def get_enemy_stats(enemy_name):
    """
    Get stats for an enemy.
    
    Args:
        enemy_name (str): The name of the enemy
        
    Returns:
        dict: Enemy stats or None if not found
    """
    # Check regular enemies
    if enemy_name in ENEMIES:
        return ENEMIES[enemy_name]
    
    # Check adventure enemies
    if enemy_name in ADVENTURE_ENEMIES:
        return ADVENTURE_ENEMIES[enemy_name]
    
    return None

def get_gather_reward(action):
    """
    Get rewards for a gathering action.
    
    Args:
        action (str): The gathering action (mine, chop, forage)
        
    Returns:
        list: List of gathered items
    """
    if action not in GATHERING_REWARDS["common"]:
        return ["Miscellaneous Item"]
    
    common_items = GATHERING_REWARDS["common"][action]
    rare_items = GATHERING_REWARDS["rare"][action]
    rare_chance = GATHERING_REWARDS["rare_chance"]
    
    # Always get one common item
    result = [random.choice(common_items)]
    
    # Chance for rare item
    if random.random() < rare_chance:
        result.append(random.choice(rare_items))
    
    return result