"""
Player model for BlindBanditRPG.
Defines player attributes, stats, and level progression.
"""
from config import BASE_HP, HP_PER_LEVEL, DAMAGE_BONUS_PER_LEVEL

# Base stats for different classes
CLASS_BASE_STATS = {
    "Warrior": {
        "strength": 5,
        "agility": 3,
        "intelligence": 2,
        "vitality": 5
    },
    "Spellblade": {
        "strength": 3,
        "agility": 3,
        "intelligence": 4,
        "vitality": 3
    },
    "Rogue": {
        "strength": 3,
        "agility": 5,
        "intelligence": 3,
        "vitality": 2
    },
    "Hunter": {
        "strength": 3,
        "agility": 4,
        "intelligence": 2,
        "vitality": 4
    },
    "Paladin": {
        "strength": 4,
        "agility": 2,
        "intelligence": 3,
        "vitality": 5
    },
    "Gunslinger": {
        "strength": 3,
        "agility": 5,
        "intelligence": 3,
        "vitality": 2
    },
    "Elementalist": {
        "strength": 2,
        "agility": 3,
        "intelligence": 5,
        "vitality": 3
    },
    "Necromancer": {
        "strength": 2,
        "agility": 2,
        "intelligence": 5,
        "vitality": 3
    },
    "Berserker": {
        "strength": 5,
        "agility": 3,
        "intelligence": 1,
        "vitality": 4
    },
    "Druid": {
        "strength": 2,
        "agility": 3,
        "intelligence": 4,
        "vitality": 4
    },
    "Monk": {
        "strength": 4,
        "agility": 4,
        "intelligence": 3,
        "vitality": 2
    },
    "Alchemist": {
        "strength": 2,
        "agility": 3,
        "intelligence": 5,
        "vitality": 2
    },
    "Witch": {
        "strength": 2,
        "agility": 3,
        "intelligence": 5,
        "vitality": 2
    },
    "Fairy": {
        "strength": 2,
        "agility": 4,
        "intelligence": 4,
        "vitality": 2
    }
}

# Default stats for new characters
DEFAULT_STATS = {
    "strength": 3,
    "agility": 3,
    "intelligence": 3,
    "vitality": 3
}

# Stat benefits
STAT_BENEFITS = {
    "strength": {
        "description": "Increases damage with melee weapons",
        "bonus_per_point": {
            "damage": 0.5
        }
    },
    "agility": {
        "description": "Increases chance to dodge and crit",
        "bonus_per_point": {
            "dodge_chance": 0.5,  # % chance
            "crit_chance": 0.5    # % chance
        }
    },
    "intelligence": {
        "description": "Increases magic damage and XP gain",
        "bonus_per_point": {
            "magic_damage": 0.5,
            "xp_bonus": 1.0      # % bonus
        }
    },
    "vitality": {
        "description": "Increases max HP",
        "bonus_per_point": {
            "hp": 3
        }
    }
}

# Experience needed per level
def xp_required(level):
    """Calculate XP required for next level"""
    return level * 100

def calculate_max_hp(player):
    """Calculate a player's maximum HP based on level and vitality"""
    base = BASE_HP
    level_bonus = player["level"] * HP_PER_LEVEL
    vitality_bonus = player.get("stats", {}).get("vitality", 3) * STAT_BENEFITS["vitality"]["bonus_per_point"]["hp"]
    
    return int(base + level_bonus + vitality_bonus)

def calculate_damage_bonus(player):
    """Calculate a player's damage bonus based on level and strength"""
    level_bonus = player["level"] * DAMAGE_BONUS_PER_LEVEL
    strength = player.get("stats", {}).get("strength", 3)
    strength_bonus = strength * STAT_BENEFITS["strength"]["bonus_per_point"]["damage"]
    
    return int(level_bonus + strength_bonus)

def calculate_crit_chance(player):
    """Calculate a player's critical hit chance"""
    base_chance = 5  # 5% base chance
    agility = player.get("stats", {}).get("agility", 3)
    agility_bonus = agility * STAT_BENEFITS["agility"]["bonus_per_point"]["crit_chance"]
    
    return base_chance + agility_bonus

def calculate_dodge_chance(player):
    """Calculate a player's dodge chance"""
    base_chance = 3  # 3% base chance
    agility = player.get("stats", {}).get("agility", 3)
    agility_bonus = agility * STAT_BENEFITS["agility"]["bonus_per_point"]["dodge_chance"]
    
    return base_chance + agility_bonus

def calculate_xp_bonus(player):
    """Calculate a player's XP gain bonus"""
    base_bonus = 0  # 0% base bonus
    intelligence = player.get("stats", {}).get("intelligence", 3)
    intelligence_bonus = intelligence * STAT_BENEFITS["intelligence"]["bonus_per_point"]["xp_bonus"]
    
    return base_bonus + intelligence_bonus

def get_level_rewards(new_level):
    """Get rewards for reaching a new level"""
    rewards = {
        "skill_points": 1,
        "hp": BASE_HP + (new_level * HP_PER_LEVEL)
    }
    
    # Special level milestones
    if new_level % 5 == 0:  # Every 5 levels
        rewards["skill_points"] = 2
        rewards["bonus_item"] = f"Level {new_level} Milestone Chest"
    
    return rewards

def apply_level_up(player):
    """Apply level up effects to a player"""
    player["level"] += 1
    new_level = player["level"]
    
    # Reset XP to overflow
    next_level_xp = xp_required(new_level - 1)  # XP needed for the level we just reached
    player["xp"] -= next_level_xp
    
    # Get level up rewards
    rewards = get_level_rewards(new_level)
    
    # Add skill points
    if "skill_points" not in player:
        player["skill_points"] = 0
    player["skill_points"] += rewards["skill_points"]
    
    # Update HP
    player["hp"] = calculate_max_hp(player)
    
    # Update damage bonus
    player["gear"]["damage_bonus"] = calculate_damage_bonus(player)
    
    # Add any bonus items
    if "bonus_item" in rewards:
        # Instead of importing, add the item directly
        if "inventory" not in player:
            player["inventory"] = {}
        
        item = rewards["bonus_item"]
        if item in player["inventory"]:
            player["inventory"][item] += 1
        else:
            player["inventory"][item] = 1
    
    return rewards

def initialize_player_stats(player, class_name=None):
    """Initialize a player's stats based on their class"""
    if class_name and class_name in CLASS_BASE_STATS:
        player["stats"] = CLASS_BASE_STATS[class_name].copy()
    else:
        player["stats"] = DEFAULT_STATS.copy()
    
    # Recalculate derived stats
    player["hp"] = calculate_max_hp(player)
    player["gear"]["damage_bonus"] = calculate_damage_bonus(player)
    
    return player