"""
Merchant system for BlindBanditRPG.
Allows players to buy and sell items.
"""
import discord
import random
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists

# Item prices for buying from merchant
BUY_PRICES = {
    # Consumables
    "Health Potion": 15,
    "Stamina Potion": 20,
    "Antidote": 10,
    
    # Basic gear
    "Iron Sword": 50,
    "Steel Sword": 100,
    "Leather Armor": 40,
    "Chainmail Armor": 80,
    
    # Resources
    "Wood": 5,
    "Stone": 5,
    "Iron Ore": 8,
    "Gold Ore": 20,
    "Magic Crystal": 30,
    
    # Special items
    "Teleport Scroll": 25,
    "Enchanted Map": 40
}

# Sell value is typically 50% of buy price
def get_sell_price(item_name):
    """Get the sell price for an item"""
    if item_name in BUY_PRICES:
        return max(1, BUY_PRICES[item_name] // 2)
    
    # Default pricing for items not in the buyback list
    if "Potion" in item_name:
        return 8
    elif "Sword" in item_name or "Blade" in item_name:
        return 15
    elif "Armor" in item_name:
        return 12
    elif "Ore" in item_name:
        return 3
    elif "Trophy" in item_name:
        return 5
    else:
        return 1

class Merchant(commands.Cog):
    """Merchant system commands"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    async def merchant(self, ctx):
        """Visit the merchant to buy and sell items"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Create embed for merchant
        embed = discord.Embed(
            title="🛒 Merchant",
            description="Buy and sell items for gold.",
            color=0xf39c12
        )
        
        # Show player's gold
        gold = player.get("gold", 0)
        embed.add_field(name="Your Gold", value=f"🪙 {gold}", inline=False)
        
        # Show available items to buy
        buy_list = ""
        for item, price in BUY_PRICES.items():
            buy_list += f"**{item}**: {price} gold\n"
        
        embed.add_field(
            name="Available Items",
            value=buy_list + "\nUse `!buy [item]` to purchase an item.",
            inline=False
        )
        
        # Show selling info
        embed.add_field(
            name="Sell Items",
            value="Use `!sell [item]` to sell items from your inventory.\nSell value is typically 50% of buy price.",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def buy(self, ctx, *, item_name=None):
        """Buy an item from the merchant"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        if not item_name:
            await ctx.send("Please specify an item to buy. Use `!merchant` to see available items.")
            return
        
        # Find the item (case-insensitive)
        actual_name = None
        price = 0
        
        for name, cost in BUY_PRICES.items():
            if name.lower() == item_name.lower():
                actual_name = name
                price = cost
                break
        
        if not actual_name:
            await ctx.send(f"The merchant doesn't sell '{item_name}'. Use `!merchant` to see available items.")
            return
        
        player = get_player(user_id)
        
        # Check if player has enough gold
        if "gold" not in player:
            player["gold"] = 0
        
        if player["gold"] < price:
            await ctx.send(f"You don't have enough gold to buy {actual_name}. You need {price} gold but only have {player['gold']} gold.")
            return
        
        # Add item to inventory
        if "inventory" not in player:
            player["inventory"] = {}
        
        if actual_name in player["inventory"]:
            player["inventory"][actual_name] += 1
        else:
            player["inventory"][actual_name] = 1
        
        # Deduct gold
        player["gold"] -= price
        
        # Update player
        update_player(user_id, player)
        
        await ctx.send(f"You bought a {actual_name} for {price} gold! You now have {player['gold']} gold remaining.")
    
    @commands.command()
    async def sell(self, ctx, *, item_name=None):
        """Sell an item to the merchant"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        if not item_name:
            await ctx.send("Please specify an item to sell. Use `!inventory` to see your items.")
            return
        
        player = get_player(user_id)
        
        # Check if player has the item
        if "inventory" not in player or not player["inventory"]:
            await ctx.send("You don't have any items to sell.")
            return
        
        # Find the item (case-insensitive)
        actual_name = None
        
        for name in player["inventory"].keys():
            if name.lower() == item_name.lower():
                actual_name = name
                break
        
        if not actual_name:
            await ctx.send(f"You don't have '{item_name}' in your inventory.")
            return
        
        # Get sell price
        price = get_sell_price(actual_name)
        
        # Remove item from inventory
        player["inventory"][actual_name] -= 1
        if player["inventory"][actual_name] <= 0:
            del player["inventory"][actual_name]
        
        # Add gold
        if "gold" not in player:
            player["gold"] = 0
        
        player["gold"] += price
        
        # Update player
        update_player(user_id, player)
        
        await ctx.send(f"You sold a {actual_name} for {price} gold! You now have {player['gold']} gold.")
    
    @commands.command()
    async def sellall(self, ctx, *, category=None):
        """Sell all items of a category"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has items
        if "inventory" not in player or not player["inventory"]:
            await ctx.send("You don't have any items to sell.")
            return
        
        # Categories for selling
        categories = {
            "ore": ["Iron Ore", "Gold Ore", "Coal", "Stone"],
            "resources": ["Wood", "Stone", "Iron Ore", "Gold Ore", "Coal", "Plant Fiber", "Animal Hide"],
            "potions": ["Health Potion", "Stamina Potion", "Antidote"],
            "fish": ["Small Fish", "Minnow", "River Trout", "Small Bass", "Lake Bass", "Perch", "Sunfish", 
                    "Mackerel", "Anchovy", "Salmon", "Tuna", "Rainbow Trout", "Catfish", "Goldfish"],
            "trophies": ["Trophy"]
        }
        
        if not category:
            # Show available categories
            categories_text = ", ".join(categories.keys())
            await ctx.send(f"Please specify a category to sell: {categories_text}")
            return
        
        category = category.lower()
        
        if category not in categories:
            categories_text = ", ".join(categories.keys())
            await ctx.send(f"Invalid category. Choose from: {categories_text}")
            return
        
        # Get items to sell
        total_sold = 0
        total_gold = 0
        items_sold = []
        
        for item_name, quantity in list(player["inventory"].items()):
            # Check if item matches category
            matches_category = False
            
            if category == "trophies":
                # Special case for trophies
                if "Trophy" in item_name:
                    matches_category = True
            else:
                # Standard category check
                if item_name in categories[category]:
                    matches_category = True
            
            if matches_category:
                # Sell the item
                price = get_sell_price(item_name)
                total_gold += price * quantity
                total_sold += quantity
                items_sold.append(f"{quantity}x {item_name} for {price * quantity} gold")
                
                # Remove from inventory
                del player["inventory"][item_name]
        
        if total_sold == 0:
            await ctx.send(f"You don't have any {category} to sell.")
            return
        
        # Add gold
        if "gold" not in player:
            player["gold"] = 0
        
        player["gold"] += total_gold
        
        # Update player
        update_player(user_id, player)
        
        # Create embed for sale results
        embed = discord.Embed(
            title=f"💰 Sold {total_sold} items",
            description=f"You sold all your {category} for a total of {total_gold} gold!",
            color=0xf39c12
        )
        
        items_text = "\n".join(items_sold[:15])
        if len(items_sold) > 15:
            items_text += f"\n... and {len(items_sold) - 15} more items"
        
        embed.add_field(name="Items Sold", value=items_text, inline=False)
        embed.add_field(name="Gold", value=f"You now have {player['gold']} gold.", inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name="useitem")
    async def use_item(self, ctx, *, item_name=None):
        """Use a consumable item like a potion"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        if not item_name:
            await ctx.send("Please specify an item to use. For example: `!useitem Health Potion`")
            return
        
        player = get_player(user_id)
        
        # Check if player has the item
        if "inventory" not in player or item_name not in player["inventory"] or player["inventory"].get(item_name, 0) <= 0:
            await ctx.send(f"You don't have any {item_name} in your inventory.")
            return
        
        # Handle different types of usable items
        if item_name == "Health Potion":
            # Get max HP from player model
            from models.player import calculate_max_hp
            max_hp = calculate_max_hp(player)
            
            # Apply healing
            old_hp = player["hp"]
            player["hp"] = min(player["hp"] + 50, max_hp)
            healed = player["hp"] - old_hp
            
            # Remove the item
            player["inventory"][item_name] -= 1
            if player["inventory"][item_name] <= 0:
                del player["inventory"][item_name]
            
            update_player(user_id, player)
            await ctx.send(f"You used a Health Potion and recovered {healed} HP. ({player['hp']}/{max_hp} HP)")
        
        elif item_name == "Stamina Potion":
            # Implement stamina mechanic if it exists
            # For now, just give a small XP boost
            old_xp = player["xp"]
            player["xp"] += 20
            
            # Remove the item
            player["inventory"][item_name] -= 1
            if player["inventory"][item_name] <= 0:
                del player["inventory"][item_name]
            
            update_player(user_id, player)
            await ctx.send(f"You used a Stamina Potion and gained 20 XP! ({old_xp} → {player['xp']} XP)")
        
        elif item_name == "Antidote":
            # Currently no poison effect, so just give a message
            # Remove the item
            player["inventory"][item_name] -= 1
            if player["inventory"][item_name] <= 0:
                del player["inventory"][item_name]
            
            update_player(user_id, player)
            await ctx.send("You used an Antidote. It would cure poison if you were poisoned.")
        
        elif item_name == "Teleport Scroll":
            # Simple teleport effect - just a message for now
            # Remove the item
            player["inventory"][item_name] -= 1
            if player["inventory"][item_name] <= 0:
                del player["inventory"][item_name]
            
            # Restore HP as a benefit
            from models.player import calculate_max_hp
            max_hp = calculate_max_hp(player)
            old_hp = player["hp"]
            player["hp"] = min(player["hp"] + 25, max_hp)
            healed = player["hp"] - old_hp
            
            update_player(user_id, player)
            await ctx.send(f"You used a Teleport Scroll and returned to town. You rested and recovered {healed} HP.")
        
        else:
            await ctx.send(f"This item cannot be used directly. Some items are used automatically when needed or must be equipped.")

async def setup(bot):
    await bot.add_cog(Merchant(bot))