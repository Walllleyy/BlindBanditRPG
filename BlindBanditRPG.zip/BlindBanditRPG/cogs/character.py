"""
Character management commands for BlindBanditRPG.
Handles character creation, stats, inventory, and equipment.
"""
import discord
from discord.ext import commands
from utils.data_manager import load_player_data, save_player_data, player_exists, get_player, update_player
from utils.player_utils import create_new_player, show_inventory, equip_item, repair_gear, restore_hp
from utils.player_utils_update import get_house_bonuses
from config import AVAILABLE_CLASSES
from models.player import initialize_player_stats, calculate_max_hp, calculate_damage_bonus, calculate_crit_chance, calculate_dodge_chance

class Character(commands.Cog):
    """Character management commands"""
    
    def __init__(self, bot):
        self.bot = bot
        self.last_messages = {}
    
    @commands.command()
    async def start(self, ctx):
        """Start your RPG journey"""
        user_id = str(ctx.author.id)
        
        if player_exists(user_id):
            msg = "You've already started your journey. Type `!profile` to view it."
            await ctx.send(msg)
            self.last_messages[user_id] = msg
            return
        
        # Create new player
        player = create_new_player(user_id, ctx.author.name)
        
        # Save player data
        data = load_player_data()
        data[user_id] = player
        save_player_data(data)
        
        msg = f"Welcome to **BlindBanditRPG**, {ctx.author.name}! Type `!classlist` to see available classes."
        await ctx.send(msg)
        self.last_messages[user_id] = msg
    
    @commands.command()
    async def classlist(self, ctx):
        """View available character classes"""
        user_id = str(ctx.author.id)
        
        # Create a more engaging class list
        embed = discord.Embed(
            title="Available Classes",
            description="Choose your path with `!chooseclass [name]`",
            color=0x7289da
        )
        
        # Group classes by type for better organization
        combat_classes = ["Warrior", "Berserker", "Paladin", "Monk"]
        magic_classes = ["Elementalist", "Spellblade", "Necromancer", "Witch", "Fairy"]
        ranged_classes = ["Hunter", "Gunslinger", "Rogue"]
        hybrid_classes = ["Druid", "Alchemist"]
        
        # Create field for each group
        embed.add_field(
            name="⚔️ Combat Classes",
            value="\n".join(f"• **{c}**" for c in combat_classes if c in AVAILABLE_CLASSES),
            inline=False
        )
        
        embed.add_field(
            name="🔮 Magic Classes",
            value="\n".join(f"• **{c}**" for c in magic_classes if c in AVAILABLE_CLASSES),
            inline=False
        )
        
        embed.add_field(
            name="🏹 Ranged Classes",
            value="\n".join(f"• **{c}**" for c in ranged_classes if c in AVAILABLE_CLASSES),
            inline=False
        )
        
        embed.add_field(
            name="🧪 Hybrid Classes",
            value="\n".join(f"• **{c}**" for c in hybrid_classes if c in AVAILABLE_CLASSES),
            inline=False
        )
        
        embed.set_footer(text="Use !allclasses for detailed class descriptions")
        
        await ctx.send(embed=embed)
        self.last_messages[user_id] = "Sent class list embed"
    
    @commands.command()
    async def chooseclass(self, ctx, *, classname):
        """Choose your character class"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            msg = "You need to start your journey first using `!start`."
            await ctx.send(msg)
            self.last_messages[user_id] = msg
            return
        
        if classname.title() not in AVAILABLE_CLASSES:
            msg = "That's not a valid class. Use `!classlist` to see your options."
            await ctx.send(msg)
            self.last_messages[user_id] = msg
            return
        
        # Update player class
        data = load_player_data()
        data[user_id]["class"] = classname.title()
        data[user_id]["gear"]["weapon"] = "Rusty " + classname.title() + " Blade"
        
        # Initialize stats based on class
        data[user_id] = initialize_player_stats(data[user_id], classname.title())
        
        save_player_data(data)
        
        # Show class details with embed
        try:
            from models.classes import get_class_description, get_unlocked_abilities
            class_desc = get_class_description(classname.title())
            
            embed = discord.Embed(
                title=f"You are now a {classname.title()}!",
                description=class_desc,
                color=0x7289da
            )
            
            # Add stat information
            stats = data[user_id]["stats"]
            embed.add_field(
                name="Starting Stats",
                value=f"💪 Strength: {stats['strength']}\n"
                    f"🏃 Agility: {stats['agility']}\n"
                    f"🧠 Intelligence: {stats['intelligence']}\n"
                    f"❤️ Vitality: {stats['vitality']}",
                inline=True
            )
            
            # Show abilities (if available)
            abilities = get_unlocked_abilities(classname.title(), 1)
            if abilities:
                ability_text = "\n".join([f"**{a['name']}** (at Level {a['level']}): {a['description']}" for a in abilities])
                embed.add_field(
                    name="Class Abilities",
                    value=ability_text or "Unlock abilities as you level up!",
                    inline=False
                )
            
            embed.set_footer(text="Type !profile to see your stats")
            
            await ctx.send(embed=embed)
        except Exception as e:
            # Fallback if classes module fails
            msg = f"You are now a **{classname.title()}**! Type `!profile` to see your stats."
            await ctx.send(msg)
            print(f"Error showing class details: {e}")
        
        self.last_messages[user_id] = f"You are now a {classname.title()}!"
    
    @commands.command()
    async def profile(self, ctx):
        """View your character profile"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            msg = "Use `!start` to begin your adventure."
            await ctx.send(msg)
            self.last_messages[user_id] = msg
            return
        
        player = get_player(user_id)
        
        # Create embed for profile
        embed = discord.Embed(
            title=f"👤 {player['name']}'s Profile",
            color=0x7289da
        )
        
        # Calculate max HP for display
        max_hp = calculate_max_hp(player)
        
        # Main character info
        embed.add_field(name="Class", value=player["class"] or "Unassigned", inline=True)
        embed.add_field(name="Level", value=player["level"], inline=True)
        embed.add_field(name="XP", value=f"{player['xp']}/{player['level'] * 100}", inline=True)
        
        # Stats section if available
        if "stats" in player:
            stats = player["stats"]
            stat_text = (
                f"💪 **Strength**: {stats.get('strength', 3)}\n"
                f"🏃 **Agility**: {stats.get('agility', 3)}\n"
                f"🧠 **Intelligence**: {stats.get('intelligence', 3)}\n"
                f"❤️ **Vitality**: {stats.get('vitality', 3)}"
            )
            embed.add_field(name="Stats", value=stat_text, inline=True)
            
            # Combat stats
            combat_stats = (
                f"❤️ **HP**: {player['hp']}/{max_hp}\n"
                f"⚔️ **Damage Bonus**: +{calculate_damage_bonus(player)}\n"
                f"⚡ **Crit Chance**: {calculate_crit_chance(player):.1f}%\n"
                f"💨 **Dodge Chance**: {calculate_dodge_chance(player):.1f}%"
            )
            embed.add_field(name="Combat Stats", value=combat_stats, inline=True)
        else:
            embed.add_field(name="HP", value=f"{player['hp']}/{max_hp}", inline=True)
        
        # Skill points if available
        if "skill_points" in player and player["skill_points"] > 0:
            embed.add_field(
                name="Available Skill Points",
                value=f"{player['skill_points']} - Use `!spend [stat] [amount]` to spend them",
                inline=False
            )
        
        # Gear section
        gear_text = (
            f"🗡️ **Weapon**: {player['gear']['weapon']}\n"
            f"🛡️ **Armor**: {player['gear']['armor']}\n"
            f"🔧 **Condition**: {player['gear'].get('condition', 'Unknown')}\n"
        )
        embed.add_field(name="Equipment", value=gear_text, inline=False)
        
        # Gold if available
        if "gold" in player:
            embed.add_field(name="Gold", value=f"🪙 {player['gold']}", inline=True)
        
        # House info if available
        try:
            if "house" in player and player["house"]["level"] > 0:
                from cogs.housing import HOUSE_LEVELS
                house_level = player["house"]["level"]
                house_info = HOUSE_LEVELS[house_level]
                house_text = (
                    f"🏠 **Level {house_level} {house_info['name']}**\n"
                    f"Rest Bonus: +{house_info['rest_bonus']} HP\n"
                    f"Storage: +{house_info['storage_bonus']} slots\n"
                    f"Income: {house_info['gold_per_day']} gold/day"
                )
                embed.add_field(name="Property", value=house_text, inline=False)
        except Exception as e:
            # If housing module isn't loaded yet
            print(f"Error displaying house info: {e}")
        
        embed.set_footer(text="Type !inventory to see your items")
        
        await ctx.send(embed=embed)
        self.last_messages[user_id] = "Sent profile embed"
    
    @commands.command(aliases=["inv", "i", "items"])
    async def inventory(self, ctx):
        """View your inventory"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            msg = "Start your journey with `!start`."
            await ctx.send(msg)
            self.last_messages[user_id] = msg
            return
        
        player = get_player(user_id)
        inventory_text = show_inventory(player)
        
        # Create embed for inventory
        embed = discord.Embed(
            title=f"🎒 {player['name']}'s Inventory",
            description=inventory_text,
            color=0x9b59b6
        )
        
        await ctx.send(embed=embed)
        self.last_messages[user_id] = "Sent inventory embed"
    
    @commands.command()
    async def equip(self, ctx, *, item):
        """Equip an item from your inventory"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("Start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        success, message = equip_item(player, item)
        
        if success:
            update_player(user_id, player)
        
        await ctx.send(message)
        self.last_messages[user_id] = message
    
    @commands.command()
    async def unequip(self, ctx, slot):
        """Unequip an item from a gear slot"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("Start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if slot exists and has an item
        if slot not in player["gear"] or player["gear"].get(slot) == "None":
            await ctx.send("You don't have anything equipped in that slot.")
            return
        
        # Get the equipped item
        item = player["gear"][slot]
        
        # Add to inventory
        if "inventory" not in player:
            player["inventory"] = {}
        player["inventory"][item] = player["inventory"].get(item, 0) + 1
        
        # Set slot to None
        player["gear"][slot] = "None"
        
        # Recalculate stats
        player["gear"]["damage_bonus"] = calculate_damage_bonus(player)
        
        # Save player data
        update_player(user_id, player)
        
        await ctx.send(f"You unequipped **{item}** from the {slot} slot.")
        self.last_messages[user_id] = f"You unequipped **{item}** from the {slot} slot."
    
    @commands.command()
    async def rest(self, ctx):
        """Rest to restore your HP"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            msg = "Start your journey with `!start` first."
            await ctx.send(msg)
            self.last_messages[user_id] = msg
            return
        
        player = get_player(user_id)
        
        # Calculate max HP
        max_hp = calculate_max_hp(player)
        
        # Don't rest if already at max HP
        if player["hp"] >= max_hp:
            await ctx.send(f"You're already at full health ({player['hp']}/{max_hp} HP).")
            return
        
        # Base healing amount (25% of max HP)
        base_healing = int(max_hp * 0.25)
        
        # Get house bonus healing if available
        try:
            from utils.player_utils_update import get_house_bonuses
            house_bonuses = get_house_bonuses(player)
            healing_amount = base_healing + house_bonuses["rest_bonus"]
            
            # Apply healing
            old_hp = player["hp"]
            player["hp"] = min(max_hp, player["hp"] + healing_amount)
            healed = player["hp"] - old_hp
            
            # Save player data
            update_player(user_id, player)
            
            # Create message with house bonus if applicable
            if house_bonuses["rest_bonus"] > 0:
                house_level = player.get("house", {}).get("level", 0)
                house_name = "house" if house_level < 5 else "manor"
                await ctx.send(f"🛌 You rest peacefully in your {house_name} and recover {healed} HP. ({player['hp']}/{max_hp} HP)\n✨ Your house provided +{house_bonuses['rest_bonus']} extra healing!")
            else:
                await ctx.send(f"🛌 You take a rest and recover {healed} HP. ({player['hp']}/{max_hp} HP)\nBuild a house with `!buildhouse` to get rest bonuses!")
            
        except Exception as e:
            # Fallback if house bonus system fails
            print(f"Error with house bonus: {e}")
            restore_hp(player)
            update_player(user_id, player)
            
            max_hp = calculate_max_hp(player)
            await ctx.send(f"🛌 You rest for a while and restore your HP to {player['hp']}/{max_hp}.")
        
        self.last_messages[user_id] = f"You rested and recovered HP."
    
    @commands.command(name="fixgear")
    async def fix_gear(self, ctx):
        """Repair your gear"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            msg = "You have no gear to repair."
            await ctx.send(msg)
            self.last_messages[user_id] = msg
            return
        
        player = get_player(user_id)
        repair_gear(player)
        update_player(user_id, player)
        
        msg = "🔧 Your gear has been repaired and restored to full condition."
        await ctx.send(msg)
        self.last_messages[user_id] = msg
    
    @commands.command()
    async def resetclass(self, ctx):
        """Reset your character class"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            msg = "Use `!start` to begin your journey first."
            await ctx.send(msg)
            self.last_messages[user_id] = msg
            return
        
        player = get_player(user_id)
        old_class = player["class"]
        
        # Calculate skill points refund
        refund_points = player["level"] - 1  # One point per level (minus starting level)
        
        # Add any existing skill points
        if "skill_points" in player:
            refund_points += player["skill_points"]
        
        # Reset class, weapon, and stats
        player["class"] = None
        player["gear"]["weapon"] = "None"
        player["stats"] = {"strength": 3, "agility": 3, "intelligence": 3, "vitality": 3}
        player["skill_points"] = refund_points
        
        # Update derived stats
        player["hp"] = calculate_max_hp(player)
        player["gear"]["damage_bonus"] = calculate_damage_bonus(player)
        
        update_player(user_id, player)
        
        msg = f"🔁 Your class has been reset from {old_class}. You now have {refund_points} skill points to spend on your next class. Use `!classlist` and `!chooseclass [name]` to pick a new one."
        await ctx.send(msg)
        self.last_messages[user_id] = msg
    
    @commands.command()
    async def save(self, ctx):
        """Save your progress"""
        data = load_player_data()
        save_player_data(data)
        msg = "✅ Your progress has been saved."
        await ctx.send(msg)
        self.last_messages[str(ctx.author.id)] = msg
    
    @commands.command()
    async def repeat(self, ctx):
        """Repeat the last message sent to you"""
        user_id = str(ctx.author.id)
        if user_id in self.last_messages:
            await ctx.send(f"🔁 Repeating:\n{self.last_messages[user_id]}")
        else:
            await ctx.send("There's nothing to repeat yet.")
    
    @commands.command()
    async def spend(self, ctx, stat: str, amount: int = 1):
        """Spend skill points on a stat"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey first using `!start`.")
            return
        
        player = get_player(user_id)
        
        # Check if player has skill points
        if "skill_points" not in player or player["skill_points"] <= 0:
            await ctx.send("You don't have any skill points to spend.")
            return
        
        # Check if amount is valid
        if amount <= 0:
            await ctx.send("You must spend at least 1 skill point.")
            return
        
        if amount > player["skill_points"]:
            await ctx.send(f"You only have {player['skill_points']} skill points.")
            return
        
        # Check if stat is valid
        valid_stats = ["strength", "agility", "intelligence", "vitality"]
        stat = stat.lower()
        
        if stat not in valid_stats:
            await ctx.send(f"Invalid stat. Choose from: {', '.join(valid_stats)}")
            return
        
        # Add stat points
        if "stats" not in player:
            player["stats"] = {"strength": 3, "agility": 3, "intelligence": 3, "vitality": 3}
        
        old_value = player["stats"][stat]
        player["stats"][stat] += amount
        player["skill_points"] -= amount
        
        # Update derived stats
        player["hp"] = calculate_max_hp(player)
        player["gear"]["damage_bonus"] = calculate_damage_bonus(player)
        
        # Save player
        update_player(user_id, player)
        
        # Send confirmation
        benefit_descriptions = {
            "strength": f"+{amount*0.5} damage bonus",
            "agility": f"+{amount*0.5}% dodge and crit chance",
            "intelligence": f"+{amount}% XP gain",
            "vitality": f"+{amount*3} max HP"
        }
        
        await ctx.send(
            f"💪 You've increased your {stat} from {old_value} to {player['stats'][stat]}!\n"
            f"Benefit: {benefit_descriptions[stat]}"
        )
        
        # Show updated stats
        await self.profile(ctx)

async def setup(bot):
    await bot.add_cog(Character(bot))