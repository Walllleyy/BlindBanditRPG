"""
Combat system for BlindBanditRPG.
Handles battles between players and enemies.
"""
import discord
import random
import asyncio
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists
from utils.player_utils import check_level_up, add_to_inventory, calculate_damage
from utils.player_utils_update import increment_stat
from models.world import get_enemy_stats
from models.player import calculate_dodge_chance, calculate_max_hp

class Combat(commands.Cog):
    """Combat commands"""
    
    def __init__(self, bot):
        self.bot = bot
        self.last_messages = {}
    
    @commands.command()
    async def battle(self, ctx):
        """Battle an enemy you've encountered"""
        user_id = str(ctx.author.id)
        
        # Get player data
        if not player_exists(user_id):
            await ctx.send("You haven't started your journey yet. Use `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player is in a battle
        if not player.get("pending_battle"):
            await ctx.send("You aren't in a battle. Use `!explore` or `!adventure` to find one.")
            return
        
        # Get enemy info
        enemy_name = player.get("current_mob", "Goblin")  # Default to Goblin if missing
        enemy = get_enemy_stats(enemy_name)
        
        if not enemy:
            # Fallback enemy if something went wrong
            enemy = {
                "hp": 30,
                "damage": (5, 10),
                "flavor": "A mysterious creature appears...",
                "loot": ["Strange Artifact"]
            }
        
        # Starting HP for both sides
        enemy_hp = enemy["hp"]
        player_hp = player["hp"]
        
        # Battle intro
        embed = discord.Embed(
            title=f"⚔️ Battle: {player['name']} vs {enemy_name}",
            description=enemy.get("flavor", f"A {enemy_name} appears!"),
            color=0xff5733
        )
        embed.add_field(name=f"{player['name']}", value=f"HP: {player_hp}", inline=True)
        embed.add_field(name=enemy_name, value=f"HP: {enemy_hp}", inline=True)
        
        battle_message = await ctx.send(embed=embed)
        
        # Combat loop
        round_num = 1
        battle_log = []
        
        while enemy_hp > 0 and player_hp > 0:
            # Short delay between rounds
            await asyncio.sleep(1)
            
            # Player's turn
            player_dmg, is_crit = calculate_damage(player)
            enemy_hp = max(0, enemy_hp - player_dmg)
            
            # Log player attack
            if is_crit:
                battle_log.append(f"⚡ **CRITICAL HIT!** You hit the {enemy_name} for {player_dmg} damage!")
            else:
                battle_log.append(f"🗡️ You hit the {enemy_name} for {player_dmg} damage!")
            
            # Check if enemy is defeated
            if enemy_hp <= 0:
                battle_log.append(f"🏆 You defeated the {enemy_name}!")
                break
            
            # Enemy's turn
            # Calculate dodge chance from player stats
            dodge_chance = calculate_dodge_chance(player)
            if random.random() * 100 < dodge_chance:
                battle_log.append(f"💨 You dodge the {enemy_name}'s attack!")
            else:
                # Enemy hits
                enemy_dmg = random.randint(*enemy["damage"])
                player_hp = max(0, player_hp - enemy_dmg)
                
                # Log enemy attack
                battle_log.append(f"💥 The {enemy_name} hits you for {enemy_dmg} damage!")
            
            # Check if player is defeated
            if player_hp <= 0:
                battle_log.append(f"💀 You were defeated by the {enemy_name}!")
                break
            
            # Update battle embed
            embed = discord.Embed(
                title=f"⚔️ Battle: {player['name']} vs {enemy_name} (Round {round_num})",
                description="\n".join(battle_log[-3:]),  # Show last 3 messages
                color=0xff5733
            )
            embed.add_field(name=f"{player['name']}", value=f"HP: {player_hp}", inline=True)
            embed.add_field(name=enemy_name, value=f"HP: {enemy_hp}", inline=True)
            await battle_message.edit(embed=embed)
            
            round_num += 1
        
        # Battle results
        player["pending_battle"] = False
        player.pop("current_mob", None)
        
        # Final battle embed
        embed = discord.Embed(
            title=f"⚔️ Battle Completed: {player['name']} vs {enemy_name}",
            description="\n".join(battle_log[-5:]),  # Show last 5 battle messages
            color=0xff5733 if player_hp <= 0 else 0x2ecc71
        )
        embed.add_field(name=f"{player['name']}", value=f"HP: {player_hp}", inline=True)
        embed.add_field(name=enemy_name, value=f"HP: {enemy_hp}", inline=True)
        
        # Handle win or loss
        if player_hp <= 0:
            # Player lost
            result_text = "💀 You were defeated in battle. Rest to recover."
            player["hp"] = 1  # Left with 1 HP after defeat
        else:
            # Player won
            # Track battle win for achievements
            player = increment_stat(player, "battles_won")
            
            # More XP for adventure battles
            xp_gain = 25 if not player.get("adventure_mode") else 40
            player["xp"] += xp_gain
            
            # Apply XP bonus from intelligence if available
            if "stats" in player and "intelligence" in player["stats"]:
                from models.player import calculate_xp_bonus
                xp_bonus_percent = calculate_xp_bonus(player)
                if xp_bonus_percent > 0:
                    bonus_xp = int(xp_gain * (xp_bonus_percent / 100))
                    player["xp"] += bonus_xp
                    xp_gain += bonus_xp
            
            # Get loot
            if "loot" in enemy:
                loot = random.choice(enemy["loot"])
            else:
                loot = enemy_name + " Trophy"
            
            add_to_inventory(player, [loot])
            
            # Check for level up
            leveled_up = check_level_up(player)
            
            # Build result text
            result_text = f"🏆 You defeated the {enemy_name} and earned {xp_gain} XP.\n🎁 Looted: {loot}"
            if leveled_up:
                result_text += f"\n🆙 You leveled up to level {player['level']}!"
                
                # Mention skill points if available
                if "skill_points" in player and player["skill_points"] > 0:
                    result_text += f"\n💪 You have {player['skill_points']} skill points to spend. Use `!spend [stat] [amount]`."
        
        # Clean up adventure mode flag
        player.pop("adventure_mode", None)
        player.pop("current_region", None)
        
        # Update player data
        player["hp"] = player_hp
        update_player(user_id, player)
        
        # Send final result
        embed.add_field(name="Result", value=result_text, inline=False)
        await battle_message.edit(embed=embed)
        
        self.last_messages[user_id] = result_text

async def setup(bot):
    await bot.add_cog(Combat(bot))