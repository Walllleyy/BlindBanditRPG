"""
Tailor system for BlindBanditRPG.
Allows players to enhance and customize their armor.
"""
import discord
import random
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists
from models.player import calculate_max_hp

# Cloth types for different armor enhancements
CLOTH_TYPES = {
    "Common Cloth": {"cost": 20, "effect": "Durability", "bonus": 5, "description": "Slightly increases armor durability"},
    "Reinforced Fabric": {"cost": 40, "effect": "HP", "bonus": 5, "description": "Adds +5 maximum HP"},
    "Silk Thread": {"cost": 60, "effect": "Agility", "bonus": 1, "description": "Adds +1 to Agility"},
    "Enchanted Wool": {"cost": 80, "effect": "Intelligence", "bonus": 1, "description": "Adds +1 to Intelligence"},
    "Mythril Weave": {"cost": 100, "effect": "HP", "bonus": 10, "description": "Adds +10 maximum HP"},
    "Dragon Scale Trim": {"cost": 150, "effect": "Resistance", "bonus": 10, "description": "Reduces damage taken by 10%"}
}

# Material requirements for upgrades
UPGRADE_MATERIALS = {
    1: {"Twigs": 3, "Cloth Scraps": 2},
    2: {"Wood": 2, "Twigs": 5, "Leather Scraps": 3},
    3: {"Wood": 4, "Leather": 2, "Sap": 1},
    4: {"Leather": 3, "Rare Bark": 1, "Sap": 2},
    5: {"Enchanted Vine": 1, "Rare Bark": 2, "Leather": 4}
}

# Maximum enhancement level
MAX_ENHANCEMENT = 5

class Tailor(commands.Cog):
    """Tailor commands for enhancing armor"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    async def tailor(self, ctx):
        """Visit the tailor to see armor enhancement options"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has armor equipped
        if "armor" not in player["gear"] or player["gear"]["armor"] == "None":
            await ctx.send("You need to have armor equipped to visit the tailor. Equip some with `!equip [armor name]`.")
            return
        
        # Get current armor and its enhancement level
        armor = player["gear"]["armor"]
        enhancement_level = 0
        
        # Extract enhancement level if it exists in the armor name
        if "+" in armor:
            base_name, level_str = armor.rsplit("+", 1)
            try:
                enhancement_level = int(level_str)
                base_name = base_name.strip()
            except ValueError:
                base_name = armor
        else:
            base_name = armor
        
        # Check if max enhancement reached
        if enhancement_level >= MAX_ENHANCEMENT:
            await ctx.send(f"Your **{armor}** is already at maximum enhancement level (+{enhancement_level}).")
            return
        
        # Get upgrade materials
        materials_needed = UPGRADE_MATERIALS.get(enhancement_level + 1, {})
        
        # Create embed for tailor information
        embed = discord.Embed(
            title="🧵 Tailor's Workshop",
            description=f"Looking to enhance your **{armor}**? I can help with that!",
            color=0x9b59b6
        )
        
        # Current armor status
        embed.add_field(
            name="Current Armor",
            value=f"**{armor}**\nEnhancement Level: +{enhancement_level}/{MAX_ENHANCEMENT}",
            inline=False
        )
        
        # Enhancement benefits
        next_level = enhancement_level + 1
        embed.add_field(
            name="Enhancement Benefits",
            value=f"+{next_level * 2} HP Bonus\nArmor becomes: **{base_name}+{next_level}**",
            inline=False
        )
        
        # Materials needed
        materials_text = ""
        for mat, qty in materials_needed.items():
            own_qty = player.get("inventory", {}).get(mat, 0)
            materials_text += f"• {own_qty}/{qty} {mat}\n"
        
        embed.add_field(
            name="Required Materials",
            value=materials_text or "No materials required",
            inline=False
        )
        
        # Cloth options
        embed.add_field(
            name="Available Cloth Options",
            value="Use `!enhance [cloth type]` to enhance your armor",
            inline=False
        )
        
        for cloth, details in CLOTH_TYPES.items():
            embed.add_field(
                name=f"{cloth} - {details['cost']} gold",
                value=f"Effect: {details['effect']} +{details['bonus']}\n{details['description']}",
                inline=True
            )
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def enhance(self, ctx, *, cloth_type):
        """Enhance your armor with special cloth"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has armor equipped
        if "armor" not in player["gear"] or player["gear"]["armor"] == "None":
            await ctx.send("You need to have armor equipped to enhance it. Equip some with `!equip [armor name]`.")
            return
        
        # Find the requested cloth type
        cloth_data = None
        cloth_name = None
        for cloth, data in CLOTH_TYPES.items():
            if cloth.lower() == cloth_type.lower():
                cloth_data = data
                cloth_name = cloth
                break
        
        if not cloth_data:
            await ctx.send(f"I don't have '{cloth_type}' available. Use `!tailor` to see available options.")
            return
        
        # Check if player has enough gold
        if player.get("gold", 0) < cloth_data["cost"]:
            await ctx.send(f"You don't have enough gold for {cloth_name}. You need {cloth_data['cost']} gold.")
            return
        
        # Get current armor and its enhancement level
        armor = player["gear"]["armor"]
        enhancement_level = 0
        
        # Extract enhancement level if it exists in the armor name
        if "+" in armor:
            base_name, level_str = armor.rsplit("+", 1)
            try:
                enhancement_level = int(level_str)
                base_name = base_name.strip()
            except ValueError:
                base_name = armor
        else:
            base_name = armor
        
        # Check if max enhancement reached
        if enhancement_level >= MAX_ENHANCEMENT:
            await ctx.send(f"Your **{armor}** is already at maximum enhancement level (+{enhancement_level}).")
            return
        
        # Get required materials
        materials_needed = UPGRADE_MATERIALS.get(enhancement_level + 1, {})
        
        # Check if player has required materials
        missing_materials = []
        for mat, qty in materials_needed.items():
            player_qty = player.get("inventory", {}).get(mat, 0)
            if player_qty < qty:
                missing_materials.append(f"{mat} ({player_qty}/{qty})")
        
        if missing_materials:
            await ctx.send(f"You're missing materials for this enhancement: {', '.join(missing_materials)}")
            return
        
        # Deduct resources
        player["gold"] -= cloth_data["cost"]
        
        for mat, qty in materials_needed.items():
            player["inventory"][mat] -= qty
            if player["inventory"][mat] <= 0:
                del player["inventory"][mat]
        
        # Apply the enhancement
        next_level = enhancement_level + 1
        new_armor_name = f"{base_name}+{next_level}"
        
        # Update armor name
        player["gear"]["armor"] = new_armor_name
        
        # Apply cloth effect
        effect = cloth_data["effect"]
        bonus = cloth_data["bonus"]
        
        if effect == "HP":
            # Add bonus directly to calculated max HP (effect handled in the calculate_max_hp function)
            if "armor_hp_bonus" not in player:
                player["armor_hp_bonus"] = 0
            player["armor_hp_bonus"] += bonus
            player["hp"] = calculate_max_hp(player)  # Update current HP
        
        elif effect == "Agility":
            if "stats" not in player:
                player["stats"] = {"strength": 3, "agility": 3, "intelligence": 3, "vitality": 3}
            player["stats"]["agility"] += bonus
        
        elif effect == "Intelligence":
            if "stats" not in player:
                player["stats"] = {"strength": 3, "agility": 3, "intelligence": 3, "vitality": 3}
            player["stats"]["intelligence"] += bonus
        
        elif effect == "Resistance":
            if "damage_reduction" not in player:
                player["damage_reduction"] = 0
            player["damage_reduction"] += bonus
        
        # Save changes
        update_player(user_id, player)
        
        await ctx.send(f"✨ **Enhancement Successful!** Your armor has been enhanced to **{new_armor_name}** with {cloth_name}! ({effect} +{bonus})")
    
    @commands.command()
    async def dye(self, ctx, *, color):
        """Dye your armor a different color"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has armor equipped
        if "armor" not in player["gear"] or player["gear"]["armor"] == "None":
            await ctx.send("You need to have armor equipped to dye it. Equip some with `!equip [armor name]`.")
            return
        
        # Valid colors with their costs
        colors = {
            "red": 15,
            "blue": 15,
            "green": 15,
            "yellow": 15,
            "purple": 20,
            "black": 25,
            "white": 25,
            "gold": 50,
            "silver": 40,
            "rainbow": 100
        }
        
        # Check if the color is valid
        if color.lower() not in colors:
            valid_colors = ", ".join(colors.keys())
            await ctx.send(f"I don't have that color available. Valid colors are: {valid_colors}")
            return
        
        # Get the color and cost
        chosen_color = color.lower()
        cost = colors[chosen_color]
        
        # Check if player has enough gold
        if player.get("gold", 0) < cost:
            await ctx.send(f"You don't have enough gold for {chosen_color} dye. You need {cost} gold.")
            return
        
        # Get current armor
        armor = player["gear"]["armor"]
        
        # Remove any existing color tag
        base_armor = armor
        for color_name in colors.keys():
            if f"({color_name})" in armor.lower():
                base_armor = armor.replace(f"({color_name.title()})", "").strip()
                break
        
        # Apply new color
        new_armor_name = f"{base_armor} ({chosen_color.title()})"
        
        # Update player data
        player["gold"] -= cost
        player["gear"]["armor"] = new_armor_name
        
        # Save changes
        update_player(user_id, player)
        
        await ctx.send(f"🎨 Your armor has been dyed {chosen_color}! It is now: **{new_armor_name}**")
    
    @commands.command(name="repairarmor")
    async def repair_armor(self, ctx):
        """Repair your armor at the tailor"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has equipment to repair
        if "gear" not in player or (player["gear"].get("armor") == "None"):
            await ctx.send("You don't have any armor to repair.")
            return
        
        # Check if repair is needed
        if player["gear"].get("condition") == "Restored":
            await ctx.send("Your armor is already in perfect condition!")
            return
        
        # Calculate repair cost (could be based on equipment value, level, etc.)
        repair_cost = 5 * player["level"]
        
        # Check if player has enough gold
        if player.get("gold", 0) < repair_cost:
            await ctx.send(f"You don't have enough gold for repairs. You need {repair_cost} gold.")
            return
        
        # Process repair
        player["gold"] -= repair_cost
        player["gear"]["condition"] = "Restored"
        
        # Save changes
        update_player(user_id, player)
        
        await ctx.send(f"🧵 Your armor has been repaired to perfect condition for {repair_cost} gold.")

async def setup(bot):
    await bot.add_cog(Tailor(bot))