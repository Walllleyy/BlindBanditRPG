"""
Housing system for BlindBanditRPG.
Allows players to build and upgrade houses.
"""
import discord
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists

# House levels with materials required and benefits
HOUSE_LEVELS = {
    0: {
        "name": "No House",
        "description": "You don't have a house yet. Build one to get bonuses!",
        "rest_bonus": 0,  # Additional HP restored when resting
        "storage_bonus": 0,  # Additional inventory slots
        "gold_per_day": 0,  # Passive gold generation
    },
    1: {
        "name": "Small Hut",
        "description": "A simple wooden hut with a small bed and storage chest.",
        "materials": {"Wood": 10},
        "rest_bonus": 10,
        "storage_bonus": 5,
        "gold_per_day": 1,
    },
    2: {
        "name": "Cottage",
        "description": "A cozy cottage with a proper bed, storage space, and a small garden.",
        "materials": {"Wood": 20, "Stone": 10},
        "rest_bonus": 20,
        "storage_bonus": 10,
        "gold_per_day": 2,
    },
    3: {
        "name": "Cabin",
        "description": "A spacious cabin with multiple rooms and improved amenities.",
        "materials": {"Wood": 30, "Stone": 20, "Iron Ore": 5},
        "rest_bonus": 30,
        "storage_bonus": 15,
        "gold_per_day": 3,
    },
    4: {
        "name": "House",
        "description": "A proper house with sturdy walls, multiple rooms, and decent furnishings.",
        "materials": {"Wood": 50, "Stone": 30, "Iron Ore": 15},
        "rest_bonus": 40,
        "storage_bonus": 20,
        "gold_per_day": 5,
    },
    5: {
        "name": "Manor",
        "description": "An impressive manor with spacious rooms, elaborate furnishings, and a beautiful garden.",
        "materials": {"Wood": 75, "Stone": 50, "Iron Ore": 25, "Gold Ore": 5},
        "rest_bonus": 60,
        "storage_bonus": 30,
        "gold_per_day": 8,
    }
}

class Housing(commands.Cog):
    """Housing system commands"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    async def house(self, ctx):
        """View your house status"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Add house level if it doesn't exist
        if "house" not in player:
            player["house"] = {
                "level": 0,
                "last_gold_claim": 0  # Unix timestamp for last passive gold claim
            }
            update_player(user_id, player)
        
        house_level = player["house"]["level"]
        house_info = HOUSE_LEVELS[house_level]
        
        # Create a pretty embed for the house info
        embed = discord.Embed(
            title=f"🏠 {player['name']}'s {house_info['name']}",
            description=house_info['description'],
            color=0x8B4513  # Brown color
        )
        
        embed.add_field(name="Level", value=f"{house_level}", inline=True)
        embed.add_field(name="Rest Bonus", value=f"+{house_info['rest_bonus']} HP", inline=True)
        embed.add_field(name="Storage Bonus", value=f"+{house_info['storage_bonus']} slots", inline=True)
        
        if house_level > 0:
            embed.add_field(name="Daily Gold", value=f"{house_info['gold_per_day']} gold/day", inline=True)
        
        # If player doesn't have a house, show building requirements
        if house_level == 0:
            level_1 = HOUSE_LEVELS[1]
            materials_text = ", ".join([f"{amount} {material}" for material, amount in level_1["materials"].items()])
            embed.add_field(name="Build a House", value=f"Use `!buildhouse` to build a Small Hut.\nRequires: {materials_text}", inline=False)
        else:
            # Show upgrade requirements if not at max level
            if house_level < max(HOUSE_LEVELS.keys()):
                next_level = HOUSE_LEVELS[house_level + 1]
                materials_text = ", ".join([f"{amount} {material}" for material, amount in next_level["materials"].items()])
                embed.add_field(name="Upgrade House", value=f"Use `!upgradehouse` to improve to a {next_level['name']}.\nRequires: {materials_text}", inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def buildhouse(self, ctx):
        """Build your first house"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Initialize house if not present
        if "house" not in player:
            player["house"] = {
                "level": 0,
                "last_gold_claim": 0
            }
        
        # Check if player already has a house
        if player["house"]["level"] > 0:
            await ctx.send(f"You already have a house! Use `!upgradehouse` to upgrade it.")
            return
        
        # Check if player has the required materials
        level_1 = HOUSE_LEVELS[1]
        can_build = True
        missing_materials = []
        
        for material, amount in level_1["materials"].items():
            player_amount = player.get("inventory", {}).get(material, 0)
            if player_amount < amount:
                can_build = False
                missing_materials.append(f"{amount - player_amount} more {material}")
        
        if not can_build:
            missing_text = ", ".join(missing_materials)
            await ctx.send(f"You don't have enough materials to build a house. You need {missing_text}.")
            return
        
        # Build the house and deduct materials
        for material, amount in level_1["materials"].items():
            player["inventory"][material] -= amount
            # Remove material from inventory if quantity reaches 0
            if player["inventory"][material] == 0:
                del player["inventory"][material]
        
        player["house"]["level"] = 1
        update_player(user_id, player)
        
        await ctx.send(f"🏠 Congratulations! You've built a Small Hut. Use `!house` to see its details and benefits.")
    
    @commands.command()
    async def upgradehouse(self, ctx):
        """Upgrade your house to the next level"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Initialize house if not present
        if "house" not in player:
            player["house"] = {
                "level": 0,
                "last_gold_claim": 0
            }
            await ctx.send("You don't have a house yet. Use `!buildhouse` to build one first.")
            return
        
        current_level = player["house"]["level"]
        
        # Check if already at max level
        if current_level >= max(HOUSE_LEVELS.keys()):
            await ctx.send(f"Your {HOUSE_LEVELS[current_level]['name']} is already at the maximum level!")
            return
        
        # Check if player has a house
        if current_level == 0:
            await ctx.send("You don't have a house yet. Use `!buildhouse` to build one first.")
            return
        
        next_level = current_level + 1
        next_house = HOUSE_LEVELS[next_level]
        
        # Check if player has the required materials
        can_upgrade = True
        missing_materials = []
        
        for material, amount in next_house["materials"].items():
            player_amount = player.get("inventory", {}).get(material, 0)
            if player_amount < amount:
                can_upgrade = False
                missing_materials.append(f"{amount - player_amount} more {material}")
        
        if not can_upgrade:
            missing_text = ", ".join(missing_materials)
            await ctx.send(f"You don't have enough materials to upgrade your house. You need {missing_text}.")
            return
        
        # Upgrade the house and deduct materials
        for material, amount in next_house["materials"].items():
            player["inventory"][material] -= amount
            # Remove material from inventory if quantity reaches 0
            if player["inventory"][material] == 0:
                del player["inventory"][material]
        
        player["house"]["level"] = next_level
        update_player(user_id, player)
        
        await ctx.send(f"🏠 Congratulations! You've upgraded to a {next_house['name']}. Use `!house` to see its details and benefits.")
    
    @commands.command()
    async def houseincome(self, ctx):
        """Collect passive income from your house"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Initialize house if not present
        if "house" not in player:
            player["house"] = {
                "level": 0,
                "last_gold_claim": 0
            }
        
        house_level = player["house"]["level"]
        
        # Check if player has a house
        if house_level == 0:
            await ctx.send("You don't have a house yet. Use `!buildhouse` to build one and earn passive income.")
            return
        
        house_info = HOUSE_LEVELS[house_level]
        daily_gold = house_info["gold_per_day"]
        
        import time
        current_time = int(time.time())
        last_claim = player["house"].get("last_gold_claim", 0)
        
        # Calculate time since last claim in seconds and convert to days
        time_passed_seconds = current_time - last_claim
        time_passed_days = time_passed_seconds / (24 * 60 * 60)  # Convert seconds to days
        
        # Allow claiming every 24 hours (1 day)
        if last_claim > 0 and time_passed_days < 1:
            # Calculate time remaining
            seconds_remaining = (24 * 60 * 60) - time_passed_seconds
            hours = int(seconds_remaining / 3600)
            minutes = int((seconds_remaining % 3600) / 60)
            
            await ctx.send(f"You can collect your house income again in {hours} hours and {minutes} minutes.")
            return
        
        # Calculate gold to award (minimum 1 day, maximum 7 days to prevent excessive accumulation)
        days_to_award = min(max(1, int(time_passed_days)), 7)
        gold_to_award = daily_gold * days_to_award
        
        # Initialize gold if not present
        if "gold" not in player:
            player["gold"] = 0
        
        # Award gold and update last claim time
        player["gold"] += gold_to_award
        player["house"]["last_gold_claim"] = current_time
        update_player(user_id, player)
        
        if days_to_award == 1:
            await ctx.send(f"📈 You collected {gold_to_award} gold from your house income.")
        else:
            await ctx.send(f"📈 You collected {gold_to_award} gold from your house income (for {days_to_award} days).")

async def setup(bot):
    await bot.add_cog(Housing(bot))