"""
Jeweler system for BlindBanditRPG.
Allows players to craft rings and amulets with magical properties.
"""
import discord
import random
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists
from utils.player_utils_update import increment_stat

# Jeweler materials and crafting requirements
MATERIALS = {
    "metals": ["Silver", "Gold", "Platinum", "Mythril"],
    "gems": ["Ruby", "Sapphire", "Emerald", "Diamond", "Amethyst", "Topaz"],
    "enchantments": ["Protection", "Power", "Wisdom", "Agility", "Vitality", "Luck"]
}

# Material value tiers
METAL_VALUES = {
    "Silver": 1,
    "Gold": 2,
    "Platinum": 3,
    "Mythril": 5
}

GEM_VALUES = {
    "Ruby": 2,
    "Sapphire": 2,
    "Emerald": 2,
    "Topaz": 2,
    "Amethyst": 3,
    "Diamond": 5
}

# Bonus provided by enchantments
ENCHANTMENT_EFFECTS = {
    "Protection": {"effect": "damage_reduction", "value": 0.05},  # 5% less damage
    "Power": {"effect": "damage_bonus", "value": 2},  # +2 damage
    "Wisdom": {"effect": "xp_bonus", "value": 0.05},  # 5% more XP
    "Agility": {"effect": "dodge_bonus", "value": 0.02},  # 2% dodge chance
    "Vitality": {"effect": "hp_bonus", "value": 10},  # +10 max HP
    "Luck": {"effect": "loot_bonus", "value": 0.1}  # 10% better loot
}

# Base crafting costs
RING_COST = {
    "metal": 2,
    "gem": 1,
    "magic_crystal": 1
}

AMULET_COST = {
    "metal": 3,
    "gem": 2,
    "magic_crystal": 2
}

class Jeweler(commands.Cog):
    """Jeweler system for crafting magical accessories"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    async def jeweler(self, ctx):
        """Visit the jeweler to craft magical jewelry"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Create embed to display jeweler services
        embed = discord.Embed(
            title="💎 Magical Jeweler",
            description="Craft powerful magical jewelry that provides stat bonuses.",
            color=0x9b59b6
        )
        
        # Add ring crafting info
        embed.add_field(
            name="🔵 Craft a Ring",
            value="Use `!craftring [metal] [gem]` to create a magical ring.\n"
                f"Cost: {RING_COST['metal']} metal, {RING_COST['gem']} gem, {RING_COST['magic_crystal']} Magic Crystal",
            inline=False
        )
        
        # Add amulet crafting info
        embed.add_field(
            name="🟣 Craft an Amulet",
            value="Use `!craftamulet [metal] [gem]` to create a magical amulet.\n"
                f"Cost: {AMULET_COST['metal']} metal, {AMULET_COST['gem']} gems, {AMULET_COST['magic_crystal']} Magic Crystals",
            inline=False
        )
        
        # List available materials
        metals_text = ", ".join(MATERIALS["metals"])
        gems_text = ", ".join(MATERIALS["gems"])
        
        embed.add_field(
            name="Available Materials",
            value=f"**Metals**: {metals_text}\n**Gems**: {gems_text}",
            inline=False
        )
        
        # Add enchantment info
        enchantments_text = "\n".join([f"• **{name}**: {ENCHANTMENT_EFFECTS[name]['effect'].replace('_', ' ').title()}" for name in MATERIALS["enchantments"]])
        
        embed.add_field(
            name="Possible Enchantments",
            value="Rings and amulets are randomly enchanted when crafted.\n" + enchantments_text,
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def craftring(self, ctx, metal=None, gem=None):
        """Craft a magical ring"""
        await self._craft_jewelry(ctx, "ring", metal, gem)
    
    @commands.command()
    async def craftamulet(self, ctx, metal=None, gem=None):
        """Craft a magical amulet"""
        await self._craft_jewelry(ctx, "amulet", metal, gem)
    
    async def _craft_jewelry(self, ctx, item_type, metal=None, gem=None):
        """Craft a piece of jewelry"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        if not metal or not gem:
            await ctx.send(f"Please specify the materials. Usage: `!craft{item_type} [metal] [gem]`")
            return
        
        # Normalize metal and gem names
        metal = metal.title()
        gem = gem.title()
        
        # Check if materials are valid
        if metal not in MATERIALS["metals"]:
            await ctx.send(f"Invalid metal. Choose from: {', '.join(MATERIALS['metals'])}")
            return
        
        if gem not in MATERIALS["gems"]:
            await ctx.send(f"Invalid gem. Choose from: {', '.join(MATERIALS['gems'])}")
            return
        
        player = get_player(user_id)
        
        # Check if player has the materials
        if "inventory" not in player:
            player["inventory"] = {}
        
        cost = RING_COST if item_type == "ring" else AMULET_COST
        
        # Check metal
        metal_cost = cost["metal"]
        if player["inventory"].get(metal, 0) < metal_cost:
            await ctx.send(f"You don't have enough {metal}. You need {metal_cost} {metal}.")
            return
        
        # Check gem
        gem_cost = cost["gem"]
        if player["inventory"].get(gem, 0) < gem_cost:
            await ctx.send(f"You don't have enough {gem}. You need {gem_cost} {gem}.")
            return
        
        # Check magic crystal
        crystal_cost = cost["magic_crystal"]
        if player["inventory"].get("Magic Crystal", 0) < crystal_cost:
            await ctx.send(f"You don't have enough Magic Crystals. You need {crystal_cost} Magic Crystal.")
            return
        
        # Deduct materials
        player["inventory"][metal] -= metal_cost
        if player["inventory"][metal] <= 0:
            del player["inventory"][metal]
        
        player["inventory"][gem] -= gem_cost
        if player["inventory"][gem] <= 0:
            del player["inventory"][gem]
        
        player["inventory"]["Magic Crystal"] -= crystal_cost
        if player["inventory"]["Magic Crystal"] <= 0:
            del player["inventory"]["Magic Crystal"]
        
        # Generate a random enchantment
        enchantment = random.choice(MATERIALS["enchantments"])
        
        # Calculate item quality based on materials
        metal_value = METAL_VALUES[metal]
        gem_value = GEM_VALUES[gem]
        total_value = metal_value + gem_value
        
        # Generate item name
        item_name = f"{enchantment} {gem} {item_type.title()} of {metal}"
        
        # Create item properties
        item_properties = {
            "type": item_type,
            "metal": metal,
            "gem": gem,
            "enchantment": enchantment,
            "quality": total_value,
            "effect": ENCHANTMENT_EFFECTS[enchantment]["effect"],
            "value": ENCHANTMENT_EFFECTS[enchantment]["value"] * total_value
        }
        
        # Add item to inventory
        if "jewelry" not in player:
            player["jewelry"] = {}
        
        player["jewelry"][item_name] = item_properties
        
        # Add to regular inventory for display
        if item_name in player["inventory"]:
            player["inventory"][item_name] += 1
        else:
            player["inventory"][item_name] = 1
        
        # Track crafting for achievements
        player = increment_stat(player, "items_crafted")
        
        # Update player
        update_player(user_id, player)
        
        # Display success message with item details
        effect_name = item_properties["effect"].replace("_", " ").title()
        effect_value = item_properties["value"]
        effect_desc = f"+{effect_value}" if effect_name != "Damage Reduction" and effect_name != "Xp Bonus" and effect_name != "Loot Bonus" else f"+{int(effect_value * 100)}%"
        
        embed = discord.Embed(
            title=f"✨ You crafted a {item_name}!",
            description=f"Quality: {'★' * total_value}\nEnchantment: {enchantment}\nEffect: {effect_name} {effect_desc}",
            color=0x9b59b6
        )
        
        # Show how to equip
        embed.add_field(
            name="Equipping",
            value=f"Use `!equip {item_name}` to wear your new {item_type}.",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def jewelry(self, ctx):
        """View your crafted jewelry and their effects"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has any jewelry
        if "jewelry" not in player or not player["jewelry"]:
            await ctx.send("You don't have any jewelry. Visit the jeweler with `!jeweler` to craft some!")
            return
        
        # Create embed to display jewelry
        embed = discord.Embed(
            title=f"💎 {player['name']}'s Jewelry Collection",
            description="Your magical rings and amulets.",
            color=0x9b59b6
        )
        
        # Separate rings and amulets
        rings = {}
        amulets = {}
        
        for name, properties in player["jewelry"].items():
            if properties["type"] == "ring":
                rings[name] = properties
            else:
                amulets[name] = properties
        
        # Add rings to embed
        if rings:
            rings_text = ""
            for name, properties in rings.items():
                effect_name = properties["effect"].replace("_", " ").title()
                effect_value = properties["value"]
                effect_desc = f"+{effect_value}" if effect_name != "Damage Reduction" and effect_name != "Xp Bonus" and effect_name != "Loot Bonus" else f"+{int(effect_value * 100)}%"
                
                equipped = "✅ Equipped" if player.get("equipped_ring") == name else ""
                
                rings_text += f"**{name}** - {effect_name} {effect_desc} {equipped}\n"
            
            embed.add_field(name="Rings", value=rings_text, inline=False)
        
        # Add amulets to embed
        if amulets:
            amulets_text = ""
            for name, properties in amulets.items():
                effect_name = properties["effect"].replace("_", " ").title()
                effect_value = properties["value"]
                effect_desc = f"+{effect_value}" if effect_name != "Damage Reduction" and effect_name != "Xp Bonus" and effect_name != "Loot Bonus" else f"+{int(effect_value * 100)}%"
                
                equipped = "✅ Equipped" if player.get("equipped_amulet") == name else ""
                
                amulets_text += f"**{name}** - {effect_name} {effect_desc} {equipped}\n"
            
            embed.add_field(name="Amulets", value=amulets_text, inline=False)
        
        embed.set_footer(text="Use !equip [jewelry name] to equip a piece of jewelry")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def equipjewelry(self, ctx, *, jewelry_name):
        """Equip a piece of jewelry"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has any jewelry
        if "jewelry" not in player or not player["jewelry"]:
            await ctx.send("You don't have any jewelry to equip.")
            return
        
        # Find the jewelry piece
        found = False
        for name, properties in player["jewelry"].items():
            if name.lower() == jewelry_name.lower():
                found = True
                jewelry_name = name  # Get the correct case
                jewelry_type = properties["type"]
                break
        
        if not found:
            await ctx.send(f"You don't have a piece of jewelry called '{jewelry_name}'.")
            return
        
        # Set equipped jewelry
        if jewelry_type == "ring":
            player["equipped_ring"] = jewelry_name
        else:
            player["equipped_amulet"] = jewelry_name
        
        # Update player
        update_player(user_id, player)
        
        await ctx.send(f"You've equipped the {jewelry_name}.")
    
    @commands.command()
    async def unequipjewelry(self, ctx, jewelry_type):
        """Unequip a ring or amulet"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check jewelry type
        if jewelry_type.lower() not in ["ring", "amulet"]:
            await ctx.send("Please specify either 'ring' or 'amulet'.")
            return
        
        # Get equipped item
        equipped_key = "equipped_ring" if jewelry_type.lower() == "ring" else "equipped_amulet"
        
        if equipped_key not in player or not player[equipped_key]:
            await ctx.send(f"You don't have any {jewelry_type} equipped.")
            return
        
        # Get name of equipped item
        equipped_name = player[equipped_key]
        
        # Remove equipped status
        player.pop(equipped_key)
        
        # Update player
        update_player(user_id, player)
        
        await ctx.send(f"You've unequipped the {equipped_name}.")

async def setup(bot):
    await bot.add_cog(Jeweler(bot))