"""
Exploration commands for BlindBanditRPG.
Handles world exploration and adventure encounters.
"""
import discord
import random
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists
from utils.player_utils import check_level_up, add_to_inventory, restore_hp
from utils.player_utils_update import increment_stat, track_region_visit, get_gathering_bonus
from models.world import (
    REGIONS, get_random_flavor_text, get_random_enemy, 
    get_random_adventure_enemy, get_gather_reward
)
from config import EXPLORE_BATTLE_CHANCE, ADVENTURE_BATTLE_CHANCE

class Exploration(commands.Cog):
    """World exploration commands"""
    
    def __init__(self, bot):
        self.bot = bot
        self.last_messages = {}
    
    @commands.command()
    async def explore(self, ctx, *, region: str = "forest"):
        """Explore a region of the world"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            msg = "Start your journey with `!start` first."
            await ctx.send(msg)
            return
        
        # Normalize region name
        region = region.lower()
        
        # Check if region exists
        if region not in REGIONS:
            await ctx.send("❌ Unknown region. Try one of: forest, swamp, wasteland")
            return
        
        # Get player data
        player = get_player(user_id)
        
        # Track region visit for achievements
        player, is_new_region = track_region_visit(player, region)
        if is_new_region:
            await ctx.send(f"📍 You've discovered a new region: {region}!")
        
        # Send flavor text
        flavor_text = get_random_flavor_text(region)
        await ctx.send(flavor_text)
        
        # Random chance for battle
        if random.random() < EXPLORE_BATTLE_CHANCE:
            # Set up battle
            mob = get_random_enemy(region)
            player["pending_battle"] = True
            player["current_mob"] = mob
            player["current_region"] = region
            
            msg = f"⚔️ A **{mob}** emerges in the {region}! Type `!battle` to engage!"
        else:
            # Peaceful encounter - gain XP and maybe an item
            player["xp"] += 10
            leveled_up = check_level_up(player)
            
            # Random loot
            loot = random.choice(["Gold Coin", "Scrap", "Wild Herb"])
            add_to_inventory(player, [loot])
            
            msg = f"You scavenge the {region} and gain 10 XP.\n🪙 You found: {loot}"
            
            if leveled_up:
                msg += f"\n🆙 You leveled up to level {player['level']}!"
        
        # Save updated player data
        update_player(user_id, player)
        
        # Send result message
        await ctx.send(msg)
        self.last_messages[user_id] = msg
    
    @commands.command()
    async def adventure(self, ctx):
        """Embark on a dangerous adventure"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("Start your journey with `!start` first.")
            return
        
        # Get player data
        player = get_player(user_id)
        
        # Adventure intro message
        await ctx.send("🧭 You venture into dangerous lands...")
        
        # Higher chance for battle in adventure mode
        if random.random() < ADVENTURE_BATTLE_CHANCE:
            # Set up battle with tougher enemy
            mob = get_random_adventure_enemy()
            player["pending_battle"] = True
            player["current_mob"] = mob
            player["adventure_mode"] = True
            
            msg = f"⚠️ A powerful foe appears: **{mob}**!\nType `!battle` to engage!"
        else:
            # Peaceful encounter - gain more XP and better loot
            player["xp"] += 20
            leveled_up = check_level_up(player)
            
            # Adventure loot is better
            loot = random.choice(["Enchanted Shard", "Ancient Coin", "Potion Ingredient"])
            add_to_inventory(player, [loot])
            
            msg = f"You narrowly avoid danger and gain 20 XP.\n🎒 Found: {loot}"
            
            if leveled_up:
                msg += f"\n🆙 You leveled up to level {player['level']}!"
        
        # Save updated player data
        update_player(user_id, player)
        
        # Send result message
        await ctx.send(msg)
        self.last_messages[user_id] = msg
    
    @commands.command()
    async def mine(self, ctx):
        """Mine for resources"""
        await self._handle_gather(ctx, "mine")
    
    @commands.command()
    async def chop(self, ctx):
        """Chop trees for resources"""
        await self._handle_gather(ctx, "chop")
    
    @commands.command()
    async def forage(self, ctx):
        """Forage for resources"""
        await self._handle_gather(ctx, "forage")
    
    async def _handle_gather(self, ctx, action):
        """Handle resource gathering actions"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            msg = "Start your journey with `!start` first."
            await ctx.send(msg)
            return
        
        # Get player data
        player = get_player(user_id)
        
        # Determine gathering bonus based on tools and achievements
        resource_type = "wood" if action == "chop" else "ore" if action == "mine" else "herbs"
        bonus = get_gathering_bonus(player, resource_type)
        
        # Get gathering rewards
        rewards = get_gather_reward(action)
        
        # Add bonus items if applicable
        if bonus > 0:
            bonus_rewards = []
            for _ in range(bonus):
                bonus_rewards.extend(get_gather_reward(action))
            
            rewards.extend(bonus_rewards)
        
        add_to_inventory(player, rewards)
        
        # Track resources gathered for achievements
        player = increment_stat(player, "resources_gathered", len(rewards))
        
        # Small XP gain for gathering
        player["xp"] += 5
        leveled_up = check_level_up(player)
        
        # Save player data
        update_player(user_id, player)
        
        # Create message
        msg = f"You used `!{action}` and gathered:\n" + "\n".join(f"• {item}" for item in rewards)
        
        if bonus > 0:
            msg += f"\n\n🔨 Your tools and skills gave you {bonus} extra resources!"
            
        msg += "\n(+5 XP)"
        
        if leveled_up:
            msg += f"\n🆙 You leveled up to level {player['level']}!"
        
        # Send result
        await ctx.send(msg)
        self.last_messages[user_id] = msg
    
    @commands.command()
    async def regions(self, ctx):
        """View available regions to explore"""
        regions_list = ", ".join(region.title() for region in REGIONS.keys())
        embed = discord.Embed(
            title="🗺️ Available Regions",
            description=f"You can explore these regions:\n{regions_list}",
            color=0x3498db
        )
        
        for region in REGIONS.keys():
            mobs = ", ".join(REGIONS[region]["mobs"])
            embed.add_field(
                name=f"{region.title()}",
                value=f"Enemies: {mobs}",
                inline=False
            )
        
        embed.set_footer(text="Use !explore [region] to venture forth!")
        await ctx.send(embed=embed)
        
async def setup(bot):
    await bot.add_cog(Exploration(bot))