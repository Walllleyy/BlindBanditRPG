"""
Boss encounter system for BlindBanditRPG.
Handles boss battles and rewards.
"""
import discord
import random
import asyncio
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists
from utils.player_utils import check_level_up, add_to_inventory
from utils.player_utils_update import increment_stat
from models.player import calculate_max_hp, calculate_damage_bonus, calculate_dodge_chance, calculate_crit_chance

# Boss definitions with stats and rewards
BOSSES = {
    "Ancient Treant": {
        "level": 5,
        "hp": 200,
        "damage": (15, 25),
        "abilities": {
            "Entangle": {
                "description": "Wraps you in vines, reducing your damage for 2 turns",
                "effect": "damage_reduction",
                "value": 0.5,
                "duration": 2,
                "chance": 0.3
            },
            "Healing Sap": {
                "description": "Heals itself using magical sap",
                "effect": "heal",
                "value": 0.1,  # 10% of max HP
                "chance": 0.2
            }
        },
        "loot": {
            "xp": 200,
            "gold": 50,
            "items": ["Ancient Bark", "TreeSap Potion", "Wooden Staff"]
        },
        "description": "An ancient tree spirit awakened by dark magic."
    },
    "Cave Troll": {
        "level": 8,
        "hp": 350,
        "damage": (20, 35),
        "abilities": {
            "Regeneration": {
                "description": "Regenerates health each turn",
                "effect": "heal",
                "value": 0.05,  # 5% of max HP
                "chance": 1.0  # Always active
            },
            "Boulder Throw": {
                "description": "Throws a massive boulder causing high damage",
                "effect": "damage",
                "value": 40,
                "chance": 0.25
            }
        },
        "loot": {
            "xp": 350,
            "gold": 80,
            "items": ["Troll Tooth", "Giant Club", "Stone Pendant"]
        },
        "description": "A massive troll that lurks in mountain caves."
    },
    "Bone Knight": {
        "level": 12,
        "hp": 500,
        "damage": (30, 45),
        "abilities": {
            "Death Strike": {
                "description": "A powerful strike that can instantly reduce your HP to 1",
                "effect": "death_strike",
                "chance": 0.1
            },
            "Bone Shield": {
                "description": "Creates a shield that absorbs damage",
                "effect": "shield",
                "value": 50,
                "chance": 0.3
            }
        },
        "loot": {
            "xp": 500,
            "gold": 120,
            "items": ["Bone Armor", "Soul Gem", "Death's Edge"]
        },
        "description": "A skeletal knight bound to serve dark powers."
    }
}

def get_boss_stats(boss_name):
    """Get stats for a specific boss"""
    boss = BOSSES.get(boss_name)
    if not boss:
        # Try case-insensitive search
        for name, data in BOSSES.items():
            if name.lower() == boss_name.lower():
                return data
    return boss

def get_random_boss():
    """Get a random boss name"""
    return random.choice(list(BOSSES.keys()))

def get_boss_list():
    """Get list of available bosses with their levels"""
    return {name: data["level"] for name, data in BOSSES.items()}

class BossEncounters(commands.Cog):
    """Boss encounter commands"""
    
    def __init__(self, bot):
        self.bot = bot
        self.active_encounters = {}
    
    @commands.command()
    async def bosslist(self, ctx):
        """View available boss encounters"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        player_level = player["level"]
        
        embed = discord.Embed(
            title="👹 Available Boss Encounters",
            description="Challenge powerful foes to earn special rewards!",
            color=0xc0392b
        )
        
        for boss_name, boss_data in BOSSES.items():
            # Calculate if boss is available based on player level
            available = player_level >= boss_data["level"] - 2
            
            # Format description
            status = "✅ Available" if available else f"❌ Requires level {boss_data['level'] - 2}+"
            description = f"{boss_data['description']}\n{status}"
            
            # Show loot if available
            if available:
                loot_items = ", ".join(boss_data["loot"]["items"][:2]) + "..."
                description += f"\n💰 Rewards: {boss_data['loot']['xp']} XP, {boss_data['loot']['gold']} gold, {loot_items}"
            
            embed.add_field(
                name=f"Level {boss_data['level']} {boss_name}",
                value=description,
                inline=False
            )
        
        embed.set_footer(text="Use !boss [name] to challenge a boss")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def boss(self, ctx, *, boss_name=None):
        """Start a boss encounter"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player is already in an encounter
        if user_id in self.active_encounters:
            await ctx.send("You're already in a boss encounter! Use `!bossbattle` to continue.")
            return
        
        # Get boss name if not specified
        if not boss_name:
            await ctx.send("You need to specify a boss to challenge. Use `!bosslist` to see available bosses.")
            return
        
        # Get boss stats
        boss = get_boss_stats(boss_name)
        
        if not boss:
            await ctx.send(f"Boss '{boss_name}' not found. Use `!bosslist` to see available bosses.")
            return
        
        # Check player level requirement
        if player["level"] < boss["level"] - 2:
            await ctx.send(f"You're not strong enough to challenge this boss yet! You need to be at least level {boss['level'] - 2}.")
            return
        
        # Check player HP
        max_hp = calculate_max_hp(player)
        if player["hp"] < max_hp * 0.5:
            await ctx.send(f"You're too injured to challenge a boss! You need at least 50% HP. Use `!rest` to recover.")
            return
        
        # Set up boss encounter
        self.active_encounters[user_id] = {
            "boss_name": boss_name,
            "boss_hp": boss["hp"],
            "player_hp": player["hp"],
            "round": 0,
            "player_effects": {},
            "boss_effects": {},
            "battle_log": []
        }
        
        # Send intro message
        embed = discord.Embed(
            title=f"Boss Encounter: {boss_name}",
            description=boss["description"],
            color=0xc0392b
        )
        
        embed.add_field(
            name="Stats",
            value=f"Level: {boss['level']}\nHP: {boss['hp']}\nDamage: {boss['damage'][0]}-{boss['damage'][1]}",
            inline=True
        )
        
        # Display abilities
        abilities_text = ""
        for ability_name, ability_data in boss["abilities"].items():
            abilities_text += f"**{ability_name}**: {ability_data['description']}\n"
        
        embed.add_field(
            name="Special Abilities",
            value=abilities_text,
            inline=True
        )
        
        embed.add_field(
            name="Rewards",
            value=f"XP: {boss['loot']['xp']}\nGold: {boss['loot']['gold']}\nPossible Items: {', '.join(boss['loot']['items'])}",
            inline=False
        )
        
        embed.set_footer(text="Type !bossbattle to begin the fight!")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def bossbattle(self, ctx):
        """Battle the boss you've challenged"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        # Check if player is in a boss encounter
        if user_id not in self.active_encounters:
            await ctx.send("You haven't challenged a boss yet! Use `!boss [name]` to start an encounter.")
            return
        
        # Get encounter data
        encounter = self.active_encounters[user_id]
        boss_name = encounter["boss_name"]
        boss = get_boss_stats(boss_name)
        
        # Get player data
        player = get_player(user_id)
        
        # Create battle embed
        embed = discord.Embed(
            title=f"Boss Battle: {player['name']} vs {boss_name}",
            description=boss["description"],
            color=0xc0392b
        )
        
        embed.add_field(name=f"{player['name']}", value=f"HP: {encounter['player_hp']}", inline=True)
        embed.add_field(name=boss_name, value=f"HP: {encounter['boss_hp']}", inline=True)
        
        # Display battle log (last 3 entries)
        if encounter["battle_log"]:
            log_text = "\n".join(encounter["battle_log"][-3:])
            embed.add_field(name="Battle Log", value=log_text, inline=False)
        
        battle_message = await ctx.send(embed=embed)
        
        # Increment round
        encounter["round"] += 1
        
        # Short delay
        await asyncio.sleep(1)
        
        # Process player effects
        player_damage_mod = 1.0
        for effect, data in list(encounter["player_effects"].items()):
            # Reduce duration
            data["duration"] -= 1
            
            # Apply effect
            if effect == "damage_reduction":
                player_damage_mod *= data["value"]
                encounter["battle_log"].append(f"⛓️ You are affected by {effect}! Your damage is reduced.")
            
            # Remove expired effects
            if data["duration"] <= 0:
                del encounter["player_effects"][effect]
                encounter["battle_log"].append(f"✨ You are no longer affected by {effect}!")
        
        # Process boss effects
        for effect, data in list(encounter["boss_effects"].items()):
            # Reduce duration
            data["duration"] -= 1
            
            # Apply effect
            if effect == "shield":
                # Shield absorbs damage
                encounter["battle_log"].append(f"🛡️ {boss_name} is protected by a shield! ({data['value']} damage absorbed)")
            
            # Remove expired effects
            if data["duration"] <= 0:
                del encounter["boss_effects"][effect]
                encounter["battle_log"].append(f"✨ {boss_name} is no longer affected by {effect}!")
        
        # Player's turn
        # Calculate damage with bonuses and effects
        base_damage, is_crit = calculate_damage(player)
        player_damage = max(1, int(base_damage * player_damage_mod))
        
        # Check for shield effect
        shield_absorbed = 0
        if "shield" in encounter["boss_effects"]:
            shield_data = encounter["boss_effects"]["shield"]
            shield_value = shield_data["value"]
            
            if shield_value >= player_damage:
                shield_absorbed = player_damage
                shield_data["value"] -= player_damage
                player_damage = 0
            else:
                shield_absorbed = shield_value
                player_damage -= shield_value
                shield_data["value"] = 0
                
                # Remove shield if depleted
                if shield_data["value"] <= 0:
                    del encounter["boss_effects"]["shield"]
            
            encounter["battle_log"].append(f"🛡️ The boss's shield absorbs {shield_absorbed} damage!")
        
        # Apply damage to boss
        old_boss_hp = encounter["boss_hp"]
        encounter["boss_hp"] = max(0, encounter["boss_hp"] - player_damage)
        
        # Log attack
        if is_crit:
            encounter["battle_log"].append(f"⚡ CRITICAL HIT! You deal {player_damage} damage to {boss_name}!")
        else:
            encounter["battle_log"].append(f"🗡️ You attack {boss_name} for {player_damage} damage.")
        
        # Check if boss is defeated
        if encounter["boss_hp"] <= 0:
            # Victory!
            await self._handle_boss_victory(ctx, user_id, encounter, boss, player)
            return
        
        # Boss's turn
        # Boss regeneration if applicable
        if "Regeneration" in boss["abilities"] and random.random() < boss["abilities"]["Regeneration"]["chance"]:
            heal_amount = int(boss["hp"] * boss["abilities"]["Regeneration"]["value"])
            encounter["boss_hp"] = min(boss["hp"], encounter["boss_hp"] + heal_amount)
            encounter["battle_log"].append(f"💚 {boss_name} regenerates {heal_amount} HP!")
        
        # Process boss abilities
        for ability_name, ability_data in boss["abilities"].items():
            # Check if ability triggers
            if random.random() < ability_data["chance"]:
                # Apply ability effect
                if ability_data["effect"] == "damage_reduction":
                    encounter["player_effects"][ability_name] = {
                        "value": ability_data["value"],
                        "duration": ability_data["duration"]
                    }
                    encounter["battle_log"].append(f"🔮 {boss_name} uses {ability_name}! {ability_data['description']}")
                
                elif ability_data["effect"] == "heal":
                    heal_amount = int(boss["hp"] * ability_data["value"])
                    encounter["boss_hp"] = min(boss["hp"], encounter["boss_hp"] + heal_amount)
                    encounter["battle_log"].append(f"💚 {boss_name} uses {ability_name} and heals for {heal_amount} HP!")
                
                elif ability_data["effect"] == "damage":
                    # Direct damage ability
                    player_dodge_chance = calculate_dodge_chance(player)
                    if random.random() * 100 < player_dodge_chance:
                        encounter["battle_log"].append(f"💨 You dodge {boss_name}'s {ability_name}!")
                    else:
                        ability_damage = ability_data["value"]
                        encounter["player_hp"] = max(0, encounter["player_hp"] - ability_damage)
                        encounter["battle_log"].append(f"💥 {boss_name} uses {ability_name} for {ability_damage} damage!")
                
                elif ability_data["effect"] == "death_strike":
                    # Check for extremely low chance insta-kill
                    player_dodge_chance = calculate_dodge_chance(player)
                    if random.random() * 100 < player_dodge_chance + 50:  # Higher chance to dodge death strike
                        encounter["battle_log"].append(f"💨 You narrowly avoid {boss_name}'s deadly {ability_name}!")
                    else:
                        encounter["player_hp"] = 1  # Reduce to 1 HP
                        encounter["battle_log"].append(f"💀 {boss_name} lands a devastating {ability_name}! You're left with just 1 HP!")
                
                elif ability_data["effect"] == "shield":
                    # Create defensive shield
                    encounter["boss_effects"]["shield"] = {
                        "value": ability_data["value"],
                        "duration": 3  # Default 3 rounds if not specified
                    }
                    encounter["battle_log"].append(f"🛡️ {boss_name} creates a {ability_name} that will absorb {ability_data['value']} damage!")
        
        # Regular boss attack if no special ability used
        player_dodge_chance = calculate_dodge_chance(player)
        if random.random() * 100 < player_dodge_chance:
            encounter["battle_log"].append(f"💨 You dodge {boss_name}'s attack!")
        else:
            boss_damage = random.randint(*boss["damage"])
            encounter["player_hp"] = max(0, encounter["player_hp"] - boss_damage)
            encounter["battle_log"].append(f"💥 {boss_name} attacks you for {boss_damage} damage!")
        
        # Check if player is defeated
        if encounter["player_hp"] <= 0:
            # Defeat handling
            await self._handle_boss_defeat(ctx, user_id, encounter, boss, player)
            return
        
        # Update battle embed
        embed = discord.Embed(
            title=f"Boss Battle: {player['name']} vs {boss_name} (Round {encounter['round']})",
            description="\n".join(encounter["battle_log"][-5:]),
            color=0xc0392b
        )
        
        embed.add_field(name=f"{player['name']}", value=f"HP: {encounter['player_hp']}", inline=True)
        embed.add_field(name=boss_name, value=f"HP: {encounter['boss_hp']}", inline=True)
        embed.set_footer(text="Type !bossbattle to continue the fight!")
        
        await battle_message.edit(embed=embed)
    
    async def _handle_boss_victory(self, ctx, user_id, encounter, boss, player):
        """Handle player victory against a boss"""
        boss_name = encounter["boss_name"]
        
        # Create victory embed
        embed = discord.Embed(
            title=f"Victory! {player['name']} defeated {boss_name}",
            description=f"After an epic battle, you emerge victorious against the {boss_name}!",
            color=0x2ecc71
        )
        
        # Award XP
        xp_gain = boss["loot"]["xp"]
        player["xp"] += xp_gain
        
        # Award gold
        gold_gain = boss["loot"]["gold"]
        if "gold" not in player:
            player["gold"] = 0
        player["gold"] += gold_gain
        
        # Award random loot item
        loot_item = random.choice(boss["loot"]["items"])
        add_to_inventory(player, [loot_item])
        
        # Update battle stats for achievements
        player = increment_stat(player, "battles_won")
        player = increment_stat(player, "bosses_defeated")
        
        # Check for level up
        leveled_up = check_level_up(player)
        
        # Update player HP
        player["hp"] = encounter["player_hp"]
        
        # Update player data
        update_player(user_id, player)
        
        # Remove active encounter
        del self.active_encounters[user_id]
        
        # Build rewards text
        rewards_text = f"XP: {xp_gain}\nGold: {gold_gain}\nItem: {loot_item}"
        
        if leveled_up:
            rewards_text += f"\n🆙 You leveled up to level {player['level']}!"
        
        embed.add_field(name="Rewards", value=rewards_text, inline=False)
        embed.set_footer(text="Challenge another boss with !boss [name]")
        
        await ctx.send(embed=embed)
    
    async def _handle_boss_defeat(self, ctx, user_id, encounter, boss, player):
        """Handle player defeat against a boss"""
        boss_name = encounter["boss_name"]
        
        # Create defeat embed
        embed = discord.Embed(
            title=f"Defeat! {player['name']} was bested by {boss_name}",
            description=f"The {boss_name} proved too powerful. You barely escape with your life.",
            color=0xe74c3c
        )
        
        # Reduce gold as penalty (10% loss)
        gold_loss = 0
        if "gold" in player and player["gold"] > 0:
            gold_loss = max(1, int(player["gold"] * 0.1))
            player["gold"] -= gold_loss
        
        # Set player HP to 1
        player["hp"] = 1
        
        # Update player data
        update_player(user_id, player)
        
        # Remove active encounter
        del self.active_encounters[user_id]
        
        # Build penalty text
        penalty_text = f"You lost {gold_loss} gold in your escape.\nYour HP is reduced to 1. Use `!rest` to recover."
        
        embed.add_field(name="Penalties", value=penalty_text, inline=False)
        embed.set_footer(text="Try again after recovering with !rest")
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(BossEncounters(bot))