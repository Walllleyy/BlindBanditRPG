"""
Achievements system for BlindBanditRPG.
Tracks player accomplishments and rewards milestones.
"""
import discord
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists, load_player_data

# Achievement definitions with requirements and rewards
ACHIEVEMENTS = {
    "first_steps": {
        "name": "First Steps",
        "description": "Start your adventure and choose a class.",
        "icon": "🥾",
        "check": lambda player: player.get("class") is not None,
        "rewards": {
            "xp": 50,
            "gold": 10,
        }
    },
    "first_blood": {
        "name": "First Blood",
        "description": "Win your first battle.",
        "icon": "⚔️",
        "check": lambda player: player.get("stats", {}).get("battles_won", 0) >= 1,
        "rewards": {
            "xp": 100,
            "bonus_stat": {"strength": 1},
        }
    },
    "seasoned_fighter": {
        "name": "Seasoned Fighter",
        "description": "Win 25 battles.",
        "icon": "🏆",
        "check": lambda player: player.get("stats", {}).get("battles_won", 0) >= 25,
        "rewards": {
            "xp": 300,
            "bonus_stat": {"strength": 2},
        }
    },
    "battle_master": {
        "name": "Battle Master",
        "description": "Win 100 battles.",
        "icon": "🔱",
        "check": lambda player: player.get("stats", {}).get("battles_won", 0) >= 100,
        "rewards": {
            "xp": 1000,
            "gold": 100,
            "bonus_stat": {"strength": 3},
            "item": "Battle Master Badge"
        }
    },
    "resource_gatherer": {
        "name": "Resource Gatherer",
        "description": "Gather 50 resources.",
        "icon": "🧰",
        "check": lambda player: (
            player.get("stats", {}).get("resources_gathered", 0) >= 50
        ),
        "rewards": {
            "xp": 100,
            "bonus_stat": {"agility": 1},
        }
    },
    "master_gatherer": {
        "name": "Master Gatherer",
        "description": "Gather 200 resources.",
        "icon": "⛏️",
        "check": lambda player: (
            player.get("stats", {}).get("resources_gathered", 0) >= 200
        ),
        "rewards": {
            "xp": 300,
            "bonus_stat": {"agility": 2},
            "item": "Gathering Gloves"
        }
    },
    "crafter_apprentice": {
        "name": "Crafter's Apprentice",
        "description": "Craft 10 items.",
        "icon": "🔨",
        "check": lambda player: player.get("stats", {}).get("items_crafted", 0) >= 10,
        "rewards": {
            "xp": 150,
            "bonus_stat": {"intelligence": 1},
        }
    },
    "master_crafter": {
        "name": "Master Crafter",
        "description": "Craft 50 items.",
        "icon": "⚒️",
        "check": lambda player: player.get("stats", {}).get("items_crafted", 0) >= 50,
        "rewards": {
            "xp": 500,
            "gold": 50,
            "bonus_stat": {"intelligence": 2},
            "item": "Crafting Tools"
        }
    },
    "explorer": {
        "name": "Explorer",
        "description": "Visit 3 different regions.",
        "icon": "🧭",
        "check": lambda player: len(player.get("regions_visited", [])) >= 3,
        "rewards": {
            "xp": 200,
            "bonus_stat": {"agility": 1},
        }
    },
    "world_traveler": {
        "name": "World Traveler",
        "description": "Visit all regions in the game.",
        "icon": "🌍",
        "check": lambda player: len(player.get("regions_visited", [])) >= 6,
        "rewards": {
            "xp": 500,
            "gold": 50,
            "bonus_stat": {"agility": 2},
            "item": "Traveler's Boots"
        }
    },
    "level_up_rookie": {
        "name": "Rookie Adventurer",
        "description": "Reach level 5.",
        "icon": "📈",
        "check": lambda player: player.get("level", 1) >= 5,
        "rewards": {
            "gold": 25,
            "bonus_stat": {"vitality": 1},
        }
    },
    "level_up_skilled": {
        "name": "Skilled Adventurer",
        "description": "Reach level 10.",
        "icon": "📊",
        "check": lambda player: player.get("level", 1) >= 10,
        "rewards": {
            "gold": 50,
            "bonus_stat": {"vitality": 1},
        }
    },
    "level_up_veteran": {
        "name": "Veteran Adventurer",
        "description": "Reach level 20.",
        "icon": "📉",
        "check": lambda player: player.get("level", 1) >= 20,
        "rewards": {
            "gold": 100,
            "item": "Veteran's Medal",
            "bonus_stat": {"vitality": 2},
        }
    },
    "homeowner": {
        "name": "Homeowner",
        "description": "Build your first house.",
        "icon": "🏠",
        "check": lambda player: player.get("house", {}).get("level", 0) >= 1,
        "rewards": {
            "xp": 100,
            "item": "House Plant",
        }
    },
    "estate_owner": {
        "name": "Estate Owner",
        "description": "Upgrade your house to maximum level.",
        "icon": "🏰",
        "check": lambda player: player.get("house", {}).get("level", 0) >= 5,
        "rewards": {
            "xp": 500,
            "gold": 100,
            "bonus_stat": {"intelligence": 1, "vitality": 1},
        }
    },
}

class Achievements(commands.Cog):
    """Achievement system commands"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    async def achievements(self, ctx, page=1):
        """View your achievements and progress"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Initialize achievements if not present
        if "achievements" not in player:
            player["achievements"] = {}
        
        # Initialize stats if not present
        if "stats" not in player:
            player["stats"] = {
                "battles_won": 0,
                "resources_gathered": 0,
                "items_crafted": 0,
            }
        
        # Initialize regions_visited if not present
        if "regions_visited" not in player:
            player["regions_visited"] = []
        
        # Create achievements embed
        embed = discord.Embed(
            title=f"🏆 {player['name']}'s Achievements",
            description="Your accomplishments throughout your journey.",
            color=0xf1c40f  # Gold color
        )
        
        # Track unlocked achievements
        unlocked = []
        locked = []
        
        for ach_id, ach_data in ACHIEVEMENTS.items():
            # Check if achievement is already completed
            if ach_id in player["achievements"]:
                unlocked.append(f"{ach_data['icon']} **{ach_data['name']}** - {ach_data['description']}")
            # Check if achievement conditions are met but not yet awarded
            elif ach_data["check"](player):
                unlocked.append(f"{ach_data['icon']} **{ach_data['name']}** - {ach_data['description']} (New!)")
                # Award achievement
                await self.award_achievement(ctx, player, ach_id)
            else:
                locked.append(f"🔒 **{ach_data['name']}** - {ach_data['description']}")
        
        # Add fields to embed
        if unlocked:
            embed.add_field(name="Completed Achievements", value="\n".join(unlocked[:10]), inline=False)
        else:
            embed.add_field(name="Completed Achievements", value="You haven't earned any achievements yet. Keep playing!", inline=False)
        
        if locked:
            embed.add_field(name="Locked Achievements", value="\n".join(locked[:5]), inline=False)
        
        embed.set_footer(text=f"Page {page}/{(len(unlocked) + len(locked) + 14) // 15}. Use !achievements [page] to see more.")
        
        await ctx.send(embed=embed)
    
    async def award_achievement(self, ctx, player, achievement_id):
        """Award an achievement to a player"""
        user_id = str(ctx.author.id)
        achievement = ACHIEVEMENTS[achievement_id]
        
        # Already has this achievement
        if achievement_id in player.get("achievements", {}):
            return
        
        # Initialize achievements if not present
        if "achievements" not in player:
            player["achievements"] = {}
        
        # Mark achievement as achieved
        player["achievements"][achievement_id] = {
            "timestamp": discord.utils.utcnow().timestamp(),
            "rewarded": True
        }
        
        # Apply rewards
        rewards = achievement["rewards"]
        
        # XP reward
        if "xp" in rewards:
            player["xp"] += rewards["xp"]
        
        # Gold reward
        if "gold" in rewards:
            if "gold" not in player:
                player["gold"] = 0
            player["gold"] += rewards["gold"]
        
        # Item reward
        if "item" in rewards:
            if "inventory" not in player:
                player["inventory"] = {}
            
            item_name = rewards["item"]
            if item_name in player["inventory"]:
                player["inventory"][item_name] += 1
            else:
                player["inventory"][item_name] = 1
        
        # Stat bonus
        if "bonus_stat" in rewards:
            if "stats" not in player:
                player["stats"] = {
                    "strength": 3,
                    "agility": 3,
                    "intelligence": 3,
                    "vitality": 3
                }
            
            for stat_name, bonus in rewards["bonus_stat"].items():
                player["stats"][stat_name] += bonus
        
        # Update player data
        update_player(user_id, player)
        
        # Construct rewards text
        rewards_text = []
        if "xp" in rewards:
            rewards_text.append(f"{rewards['xp']} XP")
        if "gold" in rewards:
            rewards_text.append(f"{rewards['gold']} gold")
        if "item" in rewards:
            rewards_text.append(f"Item: {rewards['item']}")
        if "bonus_stat" in rewards:
            stat_text = ", ".join([f"+{bonus} {stat.capitalize()}" for stat, bonus in rewards["bonus_stat"].items()])
            rewards_text.append(f"Stats: {stat_text}")
        
        rewards_str = ", ".join(rewards_text)
        
        # Send achievement unlock message
        embed = discord.Embed(
            title=f"🎉 Achievement Unlocked: {achievement['icon']} {achievement['name']}",
            description=f"{achievement['description']}\n\n**Rewards:** {rewards_str}",
            color=0xf1c40f
        )
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def checkachievements(self, ctx):
        """Check all players for achievement progress"""
        if not ctx.author.guild_permissions.administrator:
            await ctx.send("This command is only available to server administrators.")
            return
        
        await ctx.send("Checking all players for achievement progress...")
        
        # Load all player data
        all_players = load_player_data()
        updated_count = 0
        
        for user_id, player in all_players.items():
            # Skip players without basic data
            if "name" not in player or "class" not in player:
                continue
            
            # Initialize achievements if not present
            if "achievements" not in player:
                player["achievements"] = {}
                updated_count += 1
            
            # Initialize stats if not present
            if "stats" not in player:
                player["stats"] = {
                    "battles_won": 0,
                    "resources_gathered": 0,
                    "items_crafted": 0,
                }
                updated_count += 1
            
            # Initialize regions_visited if not present
            if "regions_visited" not in player:
                player["regions_visited"] = []
                updated_count += 1
            
            # Check for unlocked achievements
            achievements_unlocked = 0
            for ach_id, ach_data in ACHIEVEMENTS.items():
                # Skip already awarded achievements
                if ach_id in player["achievements"]:
                    continue
                
                # Check if achievement conditions are met
                if ach_data["check"](player):
                    # Award achievement silently (without notification)
                    player["achievements"][ach_id] = {
                        "timestamp": discord.utils.utcnow().timestamp(),
                        "rewarded": True
                    }
                    
                    # Apply rewards
                    rewards = ach_data["rewards"]
                    
                    # XP reward
                    if "xp" in rewards:
                        player["xp"] += rewards["xp"]
                    
                    # Gold reward
                    if "gold" in rewards:
                        if "gold" not in player:
                            player["gold"] = 0
                        player["gold"] += rewards["gold"]
                    
                    # Item reward
                    if "item" in rewards:
                        if "inventory" not in player:
                            player["inventory"] = {}
                        
                        item_name = rewards["item"]
                        if item_name in player["inventory"]:
                            player["inventory"][item_name] += 1
                        else:
                            player["inventory"][item_name] = 1
                    
                    # Stat bonus
                    if "bonus_stat" in rewards:
                        if "stats" not in player:
                            player["stats"] = {
                                "strength": 3,
                                "agility": 3,
                                "intelligence": 3,
                                "vitality": 3
                            }
                        
                        for stat_name, bonus in rewards["bonus_stat"].items():
                            player["stats"][stat_name] += bonus
                    
                    achievements_unlocked += 1
            
            # Update player if changes were made
            if achievements_unlocked > 0:
                update_player(user_id, player)
                updated_count += 1
        
        await ctx.send(f"✅ Achievement check complete. Updated {updated_count} players.")
    
    @commands.Cog.listener()
    async def on_command_completion(self, ctx):
        """Check for achievements after commands"""
        # Skip if the command was achievements to avoid recursion
        if ctx.command.name in ["achievements", "checkachievements"]:
            return
        
        user_id = str(ctx.author.id)
        
        # Skip if not a player
        if not player_exists(user_id):
            return
        
        player = get_player(user_id)
        
        # Update achievement stats based on command used
        if ctx.command.name in ["chop", "mine", "forage", "fish"]:
            # Initialize stats if not present
            if "stats" not in player:
                player["stats"] = {}
            
            # Initialize resources_gathered if not present
            if "resources_gathered" not in player["stats"]:
                player["stats"]["resources_gathered"] = 0
            
            # Increment resources gathered
            player["stats"]["resources_gathered"] += 1
            update_player(user_id, player)
        
        elif ctx.command.name == "craft":
            # Initialize stats if not present
            if "stats" not in player:
                player["stats"] = {}
            
            # Initialize items_crafted if not present
            if "items_crafted" not in player["stats"]:
                player["stats"]["items_crafted"] = 0
            
            # Increment items crafted
            player["stats"]["items_crafted"] += 1
            update_player(user_id, player)
        
        elif ctx.command.name == "explore":
            # Check if region is tracked for the explorer achievements
            if "regions_visited" not in player:
                player["regions_visited"] = []
            
            # Get region from command context if available
            if hasattr(ctx, "region") and ctx.region and ctx.region not in player["regions_visited"]:
                player["regions_visited"].append(ctx.region)
                update_player(user_id, player)
        
        # Check for new achievements
        for ach_id, ach_data in ACHIEVEMENTS.items():
            # Skip already awarded achievements
            if ach_id in player.get("achievements", {}):
                continue
            
            # Check if achievement conditions are met
            if ach_data["check"](player):
                # Create achievement context if it's not current context
                achievement_ctx = ctx
                await self.award_achievement(achievement_ctx, player, ach_id)

async def setup(bot):
    await bot.add_cog(Achievements(bot))