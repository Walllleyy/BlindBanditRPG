"""
Fishing system for BlindBanditRPG.
Allows players to fish for resources and items.
"""
import discord
import random
import asyncio
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists
from utils.player_utils import add_to_inventory, check_level_up

# Fishing rod tiers
FISHING_RODS = {
    "Wooden Fishing Rod": {
        "cost": 20,
        "success_rate": 65,
        "loot_quality": 1.0,
        "description": "A basic fishing rod made of wood."
    },
    "Copper Fishing Rod": {
        "cost": 75,
        "success_rate": 75,
        "loot_quality": 1.2,
        "description": "A sturdier fishing rod with copper components."
    },
    "Iron Fishing Rod": {
        "cost": 150,
        "success_rate": 85,
        "loot_quality": 1.5,
        "description": "A durable iron fishing rod."
    },
    "Enchanted Fishing Rod": {
        "cost": 300,
        "success_rate": 95,
        "loot_quality": 2.0,
        "description": "A magical fishing rod that attracts rare fish."
    }
}

# Fishing locations
FISHING_LOCATIONS = {
    "pond": {
        "common": ["Small Fish", "Minnow", "Twig", "Algae"],
        "uncommon": ["Trout", "Bass", "Carp", "Water Lily"],
        "rare": ["Golden Carp", "Ancient Boot", "Small Pearl"],
        "legendary": ["Magical Koi"],
        "required_rod": "Wooden Fishing Rod"
    },
    "river": {
        "common": ["River Trout", "Small Bass", "Water Weeds", "River Stone"],
        "uncommon": ["Salmon", "Catfish", "Sturgeon", "Water Amulet"],
        "rare": ["Golden Trout", "River Pearl", "Treasure Map Piece"],
        "legendary": ["River Serpent Scale"],
        "required_rod": "Copper Fishing Rod"
    },
    "lake": {
        "common": ["Lake Bass", "Perch", "Sunfish", "Lake Weed"],
        "uncommon": ["Northern Pike", "Walleye", "Muskie", "Lake Charm"],
        "rare": ["Legendary Bass", "Lake Pearl", "Ancient Coin"],
        "legendary": ["Lake Monster Scale"],
        "required_rod": "Iron Fishing Rod"
    },
    "ocean": {
        "common": ["Mackerel", "Anchovy", "Seaweed", "Sea Shell"],
        "uncommon": ["Tuna", "Cod", "Mahi Mahi", "Sea Crystal"],
        "rare": ["Swordfish", "Sea Pearl", "Pirate's Gold Coin"],
        "legendary": ["Kraken Tentacle", "Mermaid's Scale"],
        "required_rod": "Enchanted Fishing Rod"
    }
}

# Item values for selling
FISH_VALUES = {
    # Common fish
    "Small Fish": 3,
    "Minnow": 2,
    "River Trout": 4,
    "Small Bass": 5,
    "Lake Bass": 5,
    "Perch": 4,
    "Sunfish": 3,
    "Mackerel": 5,
    "Anchovy": 4,
    
    # Uncommon fish
    "Trout": 8,
    "Bass": 10,
    "Carp": 9,
    "Salmon": 12,
    "Catfish": 15,
    "Sturgeon": 18,
    "Northern Pike": 14,
    "Walleye": 16,
    "Muskie": 20,
    "Tuna": 25,
    "Cod": 15,
    "Mahi Mahi": 20,
    
    # Rare fish
    "Golden Carp": 35,
    "Golden Trout": 40,
    "Legendary Bass": 50,
    "Swordfish": 60,
    
    # Legendary fish
    "Magical Koi": 100,
    "River Serpent Scale": 120,
    "Lake Monster Scale": 150,
    "Kraken Tentacle": 200,
    "Mermaid's Scale": 250,
    
    # Other items
    "Small Pearl": 30,
    "River Pearl": 40,
    "Lake Pearl": 50,
    "Sea Pearl": 70,
    "Ancient Coin": 25,
    "Pirate's Gold Coin": 45,
    "Treasure Map Piece": 35
}

# Catch rate probabilities
CATCH_RATES = {
    "common": 0.6,      # 60% chance
    "uncommon": 0.3,    # 30% chance
    "rare": 0.08,       # 8% chance
    "legendary": 0.02   # 2% chance
}

# Fishing cooldown in seconds
FISHING_COOLDOWN = 30

class Fishing(commands.Cog):
    """Fishing commands for catching fish and other items"""
    
    def __init__(self, bot):
        self.bot = bot
        self.fishing_cooldowns = {}
    
    @commands.command()
    async def fishmonger(self, ctx):
        """View the fishmonger's prices for different fish"""
        user_id = str(ctx.author.id)
        
        embed = discord.Embed(
            title="🐟 Fishmonger's Market",
            description="I'll buy any fish you catch! Here are my current prices:",
            color=0x3498db
        )
        
        # Common fish
        common_fish = []
        for fish, value in FISH_VALUES.items():
            if value <= 5:
                common_fish.append(f"{fish}: {value} gold")
        
        # Uncommon fish
        uncommon_fish = []
        for fish, value in FISH_VALUES.items():
            if 5 < value <= 30:
                uncommon_fish.append(f"{fish}: {value} gold")
        
        # Rare fish
        rare_fish = []
        for fish, value in FISH_VALUES.items():
            if 30 < value <= 100:
                rare_fish.append(f"{fish}: {value} gold")
        
        # Legendary fish
        legendary_fish = []
        for fish, value in FISH_VALUES.items():
            if value > 100:
                legendary_fish.append(f"{fish}: {value} gold")
        
        # Add fields
        if common_fish:
            embed.add_field(name="Common Catches", value="\n".join(common_fish), inline=False)
        if uncommon_fish:
            embed.add_field(name="Uncommon Catches", value="\n".join(uncommon_fish), inline=True)
        if rare_fish:
            embed.add_field(name="Rare Catches", value="\n".join(rare_fish), inline=True)
        if legendary_fish:
            embed.add_field(name="Legendary Catches", value="\n".join(legendary_fish), inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def fishingrods(self, ctx):
        """View available fishing rods"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        current_rod = player.get("fishing_rod", "None")
        gold = player.get("gold", 0)
        
        embed = discord.Embed(
            title="🎣 Fishing Rods",
            description="Available fishing rods for purchase:",
            color=0x3498db
        )
        
        for rod_name, rod_data in FISHING_RODS.items():
            status = ""
            if current_rod == rod_name:
                status = "**[EQUIPPED]**"
            elif rod_name in player.get("inventory", {}):
                status = "**[OWNED]**"
            
            embed.add_field(
                name=f"{rod_name} - {rod_data['cost']} gold {status}",
                value=f"{rod_data['description']}\n"
                      f"Success Rate: {rod_data['success_rate']}%\n"
                      f"Loot Quality: {rod_data['loot_quality']}x",
                inline=False
            )
        
        embed.add_field(name="Your Gold", value=f"🪙 {gold}", inline=False)
        embed.set_footer(text="Use !buyrod [rod name] to purchase a fishing rod")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def buyrod(self, ctx, *, rod_name):
        """Buy a fishing rod"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Find the rod
        rod_data = None
        for name, data in FISHING_RODS.items():
            if name.lower() == rod_name.lower():
                rod_data = data
                rod_name = name  # Use the correct case
                break
        
        if not rod_data:
            await ctx.send("That fishing rod doesn't exist. Use `!fishingrods` to see available options.")
            return
        
        # Check if player already has this rod
        if player.get("fishing_rod") == rod_name:
            await ctx.send(f"You're already using a {rod_name}.")
            return
        elif rod_name in player.get("inventory", {}):
            await ctx.send(f"You already own a {rod_name}. Use `!equiprod {rod_name}` to equip it.")
            return
        
        # Check if player has enough gold
        if player.get("gold", 0) < rod_data["cost"]:
            await ctx.send(f"You don't have enough gold. A {rod_name} costs {rod_data['cost']} gold.")
            return
        
        # Purchase the rod
        player["gold"] -= rod_data["cost"]
        
        # Add to inventory
        if "inventory" not in player:
            player["inventory"] = {}
        
        player["inventory"][rod_name] = 1
        
        # Auto-equip if player doesn't have a rod yet
        if player.get("fishing_rod") is None or player.get("fishing_rod") == "None":
            player["fishing_rod"] = rod_name
            equip_message = f" and equipped it"
        else:
            equip_message = f". Use `!equiprod {rod_name}` to equip it"
        
        # Save changes
        update_player(user_id, player)
        
        await ctx.send(f"You purchased a {rod_name} for {rod_data['cost']} gold{equip_message}.")
    
    @commands.command()
    async def equiprod(self, ctx, *, rod_name):
        """Equip a fishing rod from your inventory"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Find the rod
        rod_data = None
        for name, data in FISHING_RODS.items():
            if name.lower() == rod_name.lower():
                rod_data = data
                rod_name = name  # Use the correct case
                break
        
        if not rod_data:
            await ctx.send("That fishing rod doesn't exist. Use `!fishingrods` to see available options.")
            return
        
        # Check if player owns the rod
        if rod_name not in player.get("inventory", {}):
            await ctx.send(f"You don't own a {rod_name}. Use `!buyrod {rod_name}` to purchase one.")
            return
        
        # Equip the rod
        player["fishing_rod"] = rod_name
        
        # Save changes
        update_player(user_id, player)
        
        await ctx.send(f"You equipped your {rod_name}. You're ready to go fishing!")
    
    @commands.command()
    async def fish(self, ctx, location="pond"):
        """Go fishing at a specific location"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check for cooldown
        current_time = ctx.message.created_at.timestamp()
        if user_id in self.fishing_cooldowns:
            time_left = self.fishing_cooldowns[user_id] - current_time
            if time_left > 0:
                await ctx.send(f"You need to wait {int(time_left)} more seconds before fishing again.")
                return
        
        # Check if player has a fishing rod
        current_rod = player.get("fishing_rod")
        if not current_rod or current_rod == "None":
            await ctx.send("You need a fishing rod to go fishing. Use `!fishingrods` to see available options.")
            return
        
        # Check if location is valid
        if location.lower() not in FISHING_LOCATIONS:
            locations = ", ".join(FISHING_LOCATIONS.keys())
            await ctx.send(f"That's not a valid fishing location. Available locations: {locations}")
            return
        
        location = location.lower()
        location_data = FISHING_LOCATIONS[location]
        
        # Check if player has the required rod for this location
        required_rod = location_data["required_rod"]
        rod_tiers = list(FISHING_RODS.keys())
        
        if rod_tiers.index(current_rod) < rod_tiers.index(required_rod):
            await ctx.send(f"You need at least a {required_rod} to fish in the {location}.")
            return
        
        # Get rod data
        rod_data = FISHING_RODS[current_rod]
        
        # Start fishing
        await ctx.send(f"🎣 You cast your line into the {location}...")
        
        # Simulate fishing animation
        message = await ctx.send("Waiting for a bite... `[                    ]`")
        for i in range(1, 11):
            await asyncio.sleep(0.5)
            progress = "=" * (i * 2) + " " * (20 - i * 2)
            await message.edit(content=f"Waiting for a bite... `[{progress}]`")
        
        # Check if catch was successful
        success_rate = rod_data["success_rate"]
        if random.randint(1, 100) > success_rate:
            await message.edit(content="The fish got away! Better luck next time.")
            
            # Set cooldown
            self.fishing_cooldowns[user_id] = current_time + FISHING_COOLDOWN
            return
        
        # Determine catch rarity
        loot_quality = rod_data["loot_quality"]
        rarities = list(CATCH_RATES.keys())
        weights = list(CATCH_RATES.values())
        
        # Adjust weights based on rod quality
        if loot_quality > 1.0:
            # Decrease common, increase others
            weights[0] *= (2 - loot_quality)  # Common becomes less likely with better rods
            
            # Distribute the remaining probability
            remaining = 1.0 - weights[0]
            total_other = sum(weights[1:])
            
            if total_other > 0:
                for i in range(1, len(weights)):
                    weights[i] = weights[i] / total_other * remaining
        
        # Normalize weights
        total = sum(weights)
        weights = [w / total for w in weights]
        
        # Roll for rarity
        rarity = random.choices(rarities, weights=weights, k=1)[0]
        
        # Get random item from the rarity pool
        possible_items = location_data[rarity]
        caught_item = random.choice(possible_items)
        
        # Add to inventory
        add_to_inventory(player, [caught_item])
        
        # Add XP based on rarity
        xp_values = {"common": 3, "uncommon": 8, "rare": 15, "legendary": 30}
        xp_gained = xp_values[rarity]
        player["xp"] += xp_gained
        
        # Check for level up
        leveled_up = check_level_up(player)
        
        # Save changes
        update_player(user_id, player)
        
        # Set cooldown
        self.fishing_cooldowns[user_id] = current_time + FISHING_COOLDOWN
        
        # Build result message
        rarity_emojis = {
            "common": "🐟",
            "uncommon": "🐠",
            "rare": "✨",
            "legendary": "🌟"
        }
        
        emoji = rarity_emojis[rarity]
        value = FISH_VALUES.get(caught_item, 0)
        
        result_msg = f"{emoji} You caught a **{caught_item}**! ({rarity.title()})\n"
        result_msg += f"This is worth approximately {value} gold at the fishmonger.\n"
        result_msg += f"You gained {xp_gained} XP from fishing."
        
        if leveled_up:
            result_msg += f"\n🆙 You leveled up to level {player['level']}!"
        
        await message.edit(content=result_msg)
    
    @commands.command()
    async def sellfish(self, ctx, *, fish_name):
        """Sell a specific type of fish to the fishmonger"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has the fish
        if "inventory" not in player or fish_name not in player["inventory"] or player["inventory"][fish_name] <= 0:
            await ctx.send(f"You don't have any {fish_name} to sell.")
            return
        
        # Check if fish has a value
        if fish_name not in FISH_VALUES:
            await ctx.send(f"The fishmonger isn't interested in buying {fish_name}.")
            return
        
        # Get fish price
        price = FISH_VALUES[fish_name]
        quantity = player["inventory"][fish_name]
        total_price = price * quantity
        
        # Confirm sale
        await ctx.send(f"You have {quantity}x {fish_name}. Sell all for {total_price} gold? (yes/no)")
        
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.lower() in ["yes", "no", "y", "n"]
        
        try:
            response = await self.bot.wait_for("message", check=check, timeout=30.0)
        except asyncio.TimeoutError:
            await ctx.send("Sale cancelled due to timeout.")
            return
        
        if response.content.lower() in ["no", "n"]:
            await ctx.send("Sale cancelled.")
            return
        
        # Process the sale
        del player["inventory"][fish_name]
        
        # Add gold
        if "gold" not in player:
            player["gold"] = 0
        player["gold"] += total_price
        
        # Save changes
        update_player(user_id, player)
        
        await ctx.send(f"You sold {quantity}x {fish_name} for {total_price} gold. You now have {player['gold']} gold.")
    
    @commands.command()
    async def sellallfish(self, ctx):
        """Sell all fish in your inventory to the fishmonger"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has any fish
        if "inventory" not in player:
            await ctx.send("You don't have any fish to sell.")
            return
        
        # Find all fish in inventory
        fish_to_sell = {}
        total_price = 0
        
        for item, quantity in player["inventory"].items():
            if item in FISH_VALUES:
                fish_to_sell[item] = quantity
                total_price += FISH_VALUES[item] * quantity
        
        if not fish_to_sell:
            await ctx.send("You don't have any fish to sell.")
            return
        
        # Confirm sale
        fish_list = "\n".join([f"{qty}x {fish} ({FISH_VALUES[fish] * qty} gold)" for fish, qty in fish_to_sell.items()])
        await ctx.send(f"Here's what I can buy from you:\n{fish_list}\n\nTotal: {total_price} gold. Sell all? (yes/no)")
        
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.lower() in ["yes", "no", "y", "n"]
        
        try:
            response = await self.bot.wait_for("message", check=check, timeout=30.0)
        except asyncio.TimeoutError:
            await ctx.send("Sale cancelled due to timeout.")
            return
        
        if response.content.lower() in ["no", "n"]:
            await ctx.send("Sale cancelled.")
            return
        
        # Process the sale
        for fish in fish_to_sell:
            del player["inventory"][fish]
        
        # Add gold
        if "gold" not in player:
            player["gold"] = 0
        player["gold"] += total_price
        
        # Save changes
        update_player(user_id, player)
        
        await ctx.send(f"You sold all your fish for {total_price} gold. You now have {player['gold']} gold.")

async def setup(bot):
    await bot.add_cog(Fishing(bot))