"""
Blacksmith system for BlindBanditRPG.
Allows players to upgrade and enhance their weapons.
"""
import discord
import random
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists

# Upgrade costs and success rates
UPGRADE_COSTS = {
    0: {"gold": 20, "materials": {"Iron Ore": 1}, "success_rate": 100},
    1: {"gold": 40, "materials": {"Iron Ore": 2}, "success_rate": 95},
    2: {"gold": 70, "materials": {"Iron Ore": 3, "Coal": 1}, "success_rate": 90},
    3: {"gold": 120, "materials": {"Iron Ore": 4, "Coal": 2}, "success_rate": 85},
    4: {"gold": 200, "materials": {"Iron Ore": 5, "Coal": 3, "Silver Ore": 1}, "success_rate": 80},
    5: {"gold": 300, "materials": {"Iron Ore": 6, "Coal": 4, "Silver Ore": 2}, "success_rate": 75},
    6: {"gold": 450, "materials": {"Silver Ore": 4, "Coal": 5}, "success_rate": 70},
    7: {"gold": 650, "materials": {"Silver Ore": 5, "Coal": 6, "Crystal Shard": 1}, "success_rate": 60},
    8: {"gold": 900, "materials": {"Silver Ore": 7, "Crystal Shard": 2}, "success_rate": 50},
    9: {"gold": 1200, "materials": {"Silver Ore": 8, "Crystal Shard": 3}, "success_rate": 40}
}

# Maximum upgrade level
MAX_UPGRADE = 10

# Bonus damage per upgrade level
UPGRADE_DAMAGE_BONUS = 2

class Blacksmith(commands.Cog):
    """Blacksmith commands for upgrading weapons"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    async def blacksmith(self, ctx):
        """Visit the blacksmith to see weapon upgrade options"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has a weapon equipped
        if "weapon" not in player["gear"] or player["gear"]["weapon"] == "None":
            await ctx.send("You need to have a weapon equipped to visit the blacksmith. Equip one with `!equip [weapon name]`.")
            return
        
        # Get current weapon and its upgrade level
        weapon = player["gear"]["weapon"]
        upgrade_level = 0
        
        # Extract upgrade level if it exists in the weapon name
        if "+" in weapon:
            base_name, level_str = weapon.rsplit("+", 1)
            try:
                upgrade_level = int(level_str)
                base_name = base_name.strip()
            except ValueError:
                base_name = weapon
        else:
            base_name = weapon
        
        # Check if max upgrade reached
        if upgrade_level >= MAX_UPGRADE:
            await ctx.send(f"Your **{weapon}** is already at maximum upgrade level (+{upgrade_level}).")
            return
        
        # Get upgrade requirements
        upgrade_info = UPGRADE_COSTS.get(upgrade_level, UPGRADE_COSTS[0])
        gold_cost = upgrade_info["gold"]
        materials = upgrade_info["materials"]
        success_rate = upgrade_info["success_rate"]
        
        # Create embed for blacksmith information
        embed = discord.Embed(
            title="⚒️ Blacksmith's Forge",
            description=f"Looking to upgrade your **{weapon}**, are ya? Let me see what I can do.",
            color=0xcd6155
        )
        
        # Current weapon status
        embed.add_field(
            name="Current Weapon",
            value=f"**{weapon}**\nUpgrade Level: +{upgrade_level}/{MAX_UPGRADE}",
            inline=False
        )
        
        # Upgrade benefits
        embed.add_field(
            name="Upgrade Benefits",
            value=f"+{UPGRADE_DAMAGE_BONUS} Damage\nWeapon becomes: **{base_name}+{upgrade_level+1}**",
            inline=False
        )
        
        # Upgrade requirements
        requirements = f"🪙 **{gold_cost} Gold**\n"
        for mat, qty in materials.items():
            requirements += f"• {qty}x {mat}\n"
        requirements += f"Success Rate: {success_rate}%"
        
        embed.add_field(
            name="Upgrade Requirements",
            value=requirements,
            inline=False
        )
        
        # Player's resources
        gold = player.get("gold", 0)
        
        resources = f"🪙 **{gold}/{gold_cost} Gold**\n"
        has_all_materials = True
        
        for mat, qty in materials.items():
            player_qty = player.get("inventory", {}).get(mat, 0)
            resources += f"• {player_qty}/{qty} {mat}\n"
            if player_qty < qty:
                has_all_materials = False
        
        embed.add_field(
            name="Your Resources",
            value=resources,
            inline=False
        )
        
        # Can player afford the upgrade?
        can_afford = gold >= gold_cost and has_all_materials
        
        embed.set_footer(text=f"Use !upgrade to attempt the weapon upgrade" if can_afford else "You don't have enough resources for this upgrade.")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def upgrade(self, ctx):
        """Attempt to upgrade your equipped weapon"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has a weapon equipped
        if "weapon" not in player["gear"] or player["gear"]["weapon"] == "None":
            await ctx.send("You need to have a weapon equipped to upgrade it. Equip one with `!equip [weapon name]`.")
            return
        
        # Get current weapon and its upgrade level
        weapon = player["gear"]["weapon"]
        upgrade_level = 0
        
        # Extract upgrade level if it exists in the weapon name
        if "+" in weapon:
            base_name, level_str = weapon.rsplit("+", 1)
            try:
                upgrade_level = int(level_str)
                base_name = base_name.strip()
            except ValueError:
                base_name = weapon
        else:
            base_name = weapon
        
        # Check if max upgrade reached
        if upgrade_level >= MAX_UPGRADE:
            await ctx.send(f"Your **{weapon}** is already at maximum upgrade level (+{upgrade_level}).")
            return
        
        # Get upgrade requirements
        upgrade_info = UPGRADE_COSTS.get(upgrade_level, UPGRADE_COSTS[0])
        gold_cost = upgrade_info["gold"]
        materials = upgrade_info["materials"]
        success_rate = upgrade_info["success_rate"]
        
        # Check if player has enough gold
        if player.get("gold", 0) < gold_cost:
            await ctx.send(f"You don't have enough gold for this upgrade. You need {gold_cost} gold.")
            return
        
        # Check if player has required materials
        missing_materials = []
        for mat, qty in materials.items():
            player_qty = player.get("inventory", {}).get(mat, 0)
            if player_qty < qty:
                missing_materials.append(f"{mat} ({player_qty}/{qty})")
        
        if missing_materials:
            await ctx.send(f"You're missing materials for this upgrade: {', '.join(missing_materials)}")
            return
        
        # Deduct resources
        player["gold"] -= gold_cost
        
        for mat, qty in materials.items():
            player["inventory"][mat] -= qty
            if player["inventory"][mat] <= 0:
                del player["inventory"][mat]
        
        # Roll for success
        roll = random.randint(1, 100)
        
        if roll <= success_rate:
            # Success
            new_weapon_name = f"{base_name}+{upgrade_level+1}"
            
            # Update weapon name
            player["gear"]["weapon"] = new_weapon_name
            
            # Increase damage bonus (optional - if you're tracking per-weapon bonuses)
            weapon_bonus = player["gear"].get("damage_bonus", 0)
            player["gear"]["damage_bonus"] = weapon_bonus + UPGRADE_DAMAGE_BONUS
            
            # Save changes
            update_player(user_id, player)
            
            await ctx.send(f"🔥 **Upgrade Successful!** Your weapon has been upgraded to **{new_weapon_name}**! (+{UPGRADE_DAMAGE_BONUS} damage)")
        else:
            # Failure
            # Resources are still consumed
            update_player(user_id, player)
            
            await ctx.send(f"💥 **Upgrade Failed!** The upgrade attempt was unsuccessful, but your weapon is safe. Resources have been consumed.")
    
    @commands.command()
    async def repair(self, ctx):
        """Repair your equipment at the blacksmith"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # Check if player has equipment to repair
        if "gear" not in player or (player["gear"].get("weapon") == "None" and player["gear"].get("armor") == "None"):
            await ctx.send("You don't have any equipment to repair.")
            return
        
        # Check if repair is needed
        if player["gear"].get("condition") == "Restored":
            await ctx.send("Your equipment is already in perfect condition!")
            return
        
        # Calculate repair cost (could be based on equipment value, level, etc.)
        repair_cost = 10 * player["level"]
        
        # Check if player has enough gold
        if player.get("gold", 0) < repair_cost:
            await ctx.send(f"You don't have enough gold for repairs. You need {repair_cost} gold.")
            return
        
        # Process repair
        player["gold"] -= repair_cost
        player["gear"]["condition"] = "Restored"
        
        # Save changes
        update_player(user_id, player)
        
        await ctx.send(f"⚒️ Your equipment has been repaired to perfect condition for {repair_cost} gold.")

async def setup(bot):
    await bot.add_cog(Blacksmith(bot))