"""
Character class management for BlindBanditRPG.
Handles class selection, abilities, and skill points.
"""
import discord
from discord.ext import commands
from models.classes import get_all_class_names, get_class_description, get_class_abilities, get_starting_weapon, get_unlocked_abilities
from models.player import initialize_player_stats
from utils.data_manager import get_player, update_player, player_exists

class ClassSystem(commands.Cog):
    """Character class commands"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name="allclasses")
    async def all_classes(self, ctx):
        """View detailed descriptions of all character classes"""
        classes = get_all_class_names()
        
        # Create embed for class list
        embed = discord.Embed(
            title="Available Classes",
            description="Choose your class with `!chooseclass [name]`",
            color=0x7289da
        )
        
        # Add fields for each class
        for class_name in classes:
            description = get_class_description(class_name)
            embed.add_field(
                name=class_name,
                value=description,
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(name="viewabilities")
    async def view_abilities(self, ctx):
        """View your class abilities and when they unlock"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey first using `!start`.")
            return
        
        player = get_player(user_id)
        
        if not player["class"]:
            await ctx.send("You need to choose a class first with `!chooseclass [name]`.")
            return
        
        # Get unlocked and locked abilities
        all_abilities = get_class_abilities(player["class"])
        unlocked = get_unlocked_abilities(player["class"], player["level"])
        
        # Create embed
        embed = discord.Embed(
            title=f"{player['class']} Abilities",
            description=f"Your abilities as a level {player['level']} {player['class']}",
            color=0x7289da
        )
        
        # Add unlocked abilities
        if unlocked:
            unlocked_text = ""
            for ability in unlocked:
                unlocked_text += f"**{ability['name']}**: {ability['description']} (Cooldown: {ability['cooldown']} turns)\n"
            embed.add_field(
                name="Unlocked Abilities",
                value=unlocked_text,
                inline=False
            )
        
        # Add locked abilities
        locked_text = ""
        for ability_name, ability_data in all_abilities.items():
            if ability_data["level"] > player["level"]:
                locked_text += f"**{ability_name}** (Unlocks at Level {ability_data['level']}): {ability_data['description']}\n"
        
        if locked_text:
            embed.add_field(
                name="Locked Abilities",
                value=locked_text,
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(name="mystats")
    async def view_stats(self, ctx):
        """View detailed breakdown of your character stats"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey first using `!start`.")
            return
        
        player = get_player(user_id)
        
        # Create embed
        embed = discord.Embed(
            title=f"{player['name']}'s Detailed Stats",
            description=f"Level {player['level']} {player['class'] or 'Adventurer'}",
            color=0x7289da
        )
        
        # Add basic stats
        embed.add_field(name="HP", value=player["hp"], inline=True)
        embed.add_field(name="XP", value=f"{player['xp']}/{player['level'] * 100}", inline=True)
        
        # Add attribute stats if they exist
        if "stats" in player:
            # Primary attributes
            attributes = ""
            for stat, value in player["stats"].items():
                attributes += f"**{stat.title()}**: {value}\n"
            embed.add_field(name="Attributes", value=attributes, inline=False)
            
            # Derived stats based on attributes
            from models.player import calculate_crit_chance, calculate_dodge_chance, calculate_xp_bonus, calculate_damage_bonus
            
            derived = (
                f"**Damage Bonus**: +{calculate_damage_bonus(player)}\n"
                f"**Crit Chance**: {calculate_crit_chance(player):.1f}%\n"
                f"**Dodge Chance**: {calculate_dodge_chance(player):.1f}%\n"
                f"**XP Bonus**: {calculate_xp_bonus(player):.1f}%"
            )
            embed.add_field(name="Derived Stats", value=derived, inline=False)
            
            # Stat explanations
            explanations = (
                "**Strength**: Increases damage\n"
                "**Agility**: Increases dodge and critical chance\n"
                "**Intelligence**: Increases XP gain\n"
                "**Vitality**: Increases maximum HP"
            )
            embed.add_field(name="Stat Effects", value=explanations, inline=False)
        
        # Add skill points if available
        if "skill_points" in player and player["skill_points"] > 0:
            embed.add_field(
                name="Available Skill Points",
                value=f"{player['skill_points']} - Use `!spend [stat] [amount]` to spend them",
                inline=False
            )
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(ClassSystem(bot))