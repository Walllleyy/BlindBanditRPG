"""
Crafting system for BlindBanditRPG.
Allows players to craft items from gathered materials.
"""
import discord
import random
from discord.ext import commands
from utils.data_manager import get_player, update_player, player_exists

# Crafting recipes with ingredients and results
RECIPES = {
    "Healing Potion": {
        "ingredients": {"Herbs": 2, "Berries": 1},
        "description": "Restores 50 HP when used",
        "category": "potion"
    },
    "Stamina Potion": {
        "ingredients": {"Mushrooms": 2, "Wild Herb": 1},
        "description": "Restores energy for adventures",
        "category": "potion"
    },
    "Iron Sword": {
        "ingredients": {"Iron Ore": 3, "Wood": 1},
        "description": "+5 damage bonus",
        "category": "weapon"
    },
    "Steel Sword": {
        "ingredients": {"Iron Ore": 5, "Coal": 2, "Wood": 1},
        "description": "+8 damage bonus",
        "category": "weapon"
    },
    "Wooden Shield": {
        "ingredients": {"Wood": 5},
        "description": "Reduces damage taken by 5%",
        "category": "armor"
    },
    "Iron Shield": {
        "ingredients": {"Iron Ore": 4, "Wood": 2},
        "description": "Reduces damage taken by 10%",
        "category": "armor"
    },
    "Leather Armor": {
        "ingredients": {"Animal Hide": 5},
        "description": "Basic armor protection",
        "category": "armor"
    },
    "Stone Axe": {
        "ingredients": {"Stone": 3, "Wood": 2},
        "description": "Better gathering tool for wood (+2 wood per chop)",
        "category": "tool"
    },
    "Iron Pickaxe": {
        "ingredients": {"Iron Ore": 3, "Wood": 2},
        "description": "Better gathering tool for minerals (+2 ore per mine)",
        "category": "tool"
    },
    "Herb Bag": {
        "ingredients": {"Animal Hide": 2, "Plant Fiber": 3},
        "description": "Better gathering tool for herbs and plants (+2 per forage)",
        "category": "tool"
    },
    "Fishing Rod": {
        "ingredients": {"Wood": 3, "Plant Fiber": 2},
        "description": "Allows fishing for resources and food",
        "category": "tool"
    },
    "Advanced Fishing Rod": {
        "ingredients": {"Wood": 5, "Plant Fiber": 3, "Iron Ore": 1},
        "description": "Higher chance of rare fish",
        "category": "tool"
    },
    "Health Charm": {
        "ingredients": {"Magic Crystal": 1, "Herbs": 3},
        "description": "Passive health regeneration",
        "category": "accessory"
    },
    "Strength Charm": {
        "ingredients": {"Magic Crystal": 1, "Iron Ore": 3},
        "description": "Increases strength by 1",
        "category": "accessory"
    },
    "Agility Charm": {
        "ingredients": {"Magic Crystal": 1, "Plant Fiber": 3},
        "description": "Increases agility by 1",
        "category": "accessory"
    }
}

# Categories for organizing recipes in display
RECIPE_CATEGORIES = {
    "potion": "Potions",
    "weapon": "Weapons",
    "armor": "Armor",
    "tool": "Tools",
    "accessory": "Accessories"
}

class Crafting(commands.Cog):
    """Crafting system commands"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    async def recipes(self, ctx, category=None):
        """View available crafting recipes. Optionally filter by category."""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        # If a category is specified, filter recipes
        if category and category.lower() in [cat.lower() for cat in RECIPE_CATEGORIES.values()]:
            category_key = next(key for key, value in RECIPE_CATEGORIES.items() 
                               if value.lower() == category.lower())
            
            filtered_recipes = {name: recipe for name, recipe in RECIPES.items() 
                              if recipe["category"] == category_key}
            
            if not filtered_recipes:
                await ctx.send(f"No recipes found in the '{category}' category.")
                return
            
            embed = discord.Embed(
                title=f"📜 {category} Recipes",
                description=f"Crafting recipes for {category.lower()}.",
                color=0x1abc9c
            )
            
            for name, recipe in filtered_recipes.items():
                ingredients = ", ".join([f"{amount} {item}" for item, amount in recipe["ingredients"].items()])
                embed.add_field(
                    name=name,
                    value=f"**Ingredients:** {ingredients}\n**Effect:** {recipe['description']}",
                    inline=False
                )
        else:
            # Group recipes by category
            embed = discord.Embed(
                title="📜 Crafting Recipes",
                description="Use `!recipes [category]` to see specific recipes.\nUse `!craft [item]` to craft items.",
                color=0x1abc9c
            )
            
            # Add category listing
            categories_text = ""
            for category_name in RECIPE_CATEGORIES.values():
                # Count recipes in this category
                count = len([r for r in RECIPES.values() if r["category"] == next(
                    key for key, value in RECIPE_CATEGORIES.items() if value == category_name
                )])
                categories_text += f"• {category_name} ({count} recipes)\n"
            
            embed.add_field(name="Categories", value=categories_text, inline=False)
            
            # Add a few sample recipes
            embed.add_field(
                name="Sample Recipes",
                value="Here are a few example recipes to get you started:",
                inline=False
            )
            
            # Get one recipe from each category to show as examples
            sample_recipes = {}
            for category_key in RECIPE_CATEGORIES:
                for name, recipe in RECIPES.items():
                    if recipe["category"] == category_key and category_key not in sample_recipes:
                        sample_recipes[category_key] = (name, recipe)
                        break
            
            for category_key, (name, recipe) in sample_recipes.items():
                ingredients = ", ".join([f"{amount} {item}" for item, amount in recipe["ingredients"].items()])
                embed.add_field(
                    name=f"{name} ({RECIPE_CATEGORIES[category_key]})",
                    value=f"**Ingredients:** {ingredients}\n**Effect:** {recipe['description']}",
                    inline=True
                )
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def craft(self, ctx, *, item_name=None):
        """Craft an item using materials from your inventory."""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        # If no item specified, show recipes command help
        if not item_name:
            await ctx.send("Please specify an item to craft. Use `!recipes` to see available recipes.")
            return
        
        # Find the recipe, case-insensitive search
        matched_recipes = [name for name in RECIPES.keys() 
                         if name.lower() == item_name.lower()]
        
        # If no exact match, try partial match
        if not matched_recipes:
            matched_recipes = [name for name in RECIPES.keys() 
                             if item_name.lower() in name.lower()]
        
        # If still no match or multiple matches
        if not matched_recipes:
            await ctx.send(f"Recipe for '{item_name}' not found. Use `!recipes` to see available recipes.")
            return
        elif len(matched_recipes) > 1:
            matches_text = "\n".join(matched_recipes)
            await ctx.send(f"Multiple recipes match '{item_name}'. Please be more specific:\n{matches_text}")
            return
        
        recipe_name = matched_recipes[0]
        recipe = RECIPES[recipe_name]
        
        # Check if player has the ingredients
        if "inventory" not in player:
            player["inventory"] = {}
        
        can_craft = True
        missing_ingredients = []
        
        for ingredient, amount in recipe["ingredients"].items():
            player_amount = player["inventory"].get(ingredient, 0)
            if player_amount < amount:
                can_craft = False
                missing_ingredients.append(f"{amount - player_amount} more {ingredient}")
        
        if not can_craft:
            missing_text = ", ".join(missing_ingredients)
            await ctx.send(f"You don't have enough materials to craft {recipe_name}. You need {missing_text}.")
            return
        
        # Craft the item and deduct ingredients
        for ingredient, amount in recipe["ingredients"].items():
            player["inventory"][ingredient] -= amount
            # Remove ingredient from inventory if quantity reaches 0
            if player["inventory"][ingredient] == 0:
                del player["inventory"][ingredient]
        
        # Add crafted item to inventory
        if recipe_name in player["inventory"]:
            player["inventory"][recipe_name] += 1
        else:
            player["inventory"][recipe_name] = 1
        
        # Update player data
        update_player(user_id, player)
        
        # Success message with effects description
        await ctx.send(f"✅ You've successfully crafted a {recipe_name}!\n**Effect:** {recipe['description']}")
        
        # Add special handling for weapons/tools/armor if those systems exist
        if recipe["category"] == "weapon":
            await ctx.send(f"You can equip your new weapon with `!equip {recipe_name}`.")
        elif recipe["category"] == "armor":
            await ctx.send(f"You can equip your new armor with `!equip {recipe_name}`.")
        elif recipe["category"] == "tool":
            await ctx.send(f"Your new tool will automatically be used when gathering resources.")
    
    @commands.command()
    async def materials(self, ctx):
        """View crafting materials in your inventory"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        player = get_player(user_id)
        
        if "inventory" not in player or not player["inventory"]:
            await ctx.send("You don't have any materials in your inventory. Go explore to gather some!")
            return
        
        # List of common crafting materials
        crafting_materials = [
            "Wood", "Stone", "Iron Ore", "Gold Ore", "Coal", 
            "Animal Hide", "Plant Fiber", "Herbs", "Berries", 
            "Mushrooms", "Wild Herb", "Magic Crystal"
        ]
        
        # Filter inventory for crafting materials only
        materials = {item: amount for item, amount in player["inventory"].items() 
                   if item in crafting_materials}
        
        if not materials:
            await ctx.send("You don't have any crafting materials in your inventory. Go explore to gather some!")
            return
        
        # Create embed for materials display
        embed = discord.Embed(
            title=f"🧰 {player['name']}'s Crafting Materials",
            description="Materials you can use for crafting.",
            color=0x9b59b6
        )
        
        # Group materials by type
        wood_stone = []
        ores = []
        plants = []
        other = []
        
        for material, amount in materials.items():
            if material in ["Wood", "Stone"]:
                wood_stone.append(f"{material}: {amount}")
            elif "Ore" in material or material == "Coal":
                ores.append(f"{material}: {amount}")
            elif material in ["Herbs", "Berries", "Mushrooms", "Wild Herb", "Plant Fiber"]:
                plants.append(f"{material}: {amount}")
            else:
                other.append(f"{material}: {amount}")
        
        if wood_stone:
            embed.add_field(name="Wood & Stone", value="\n".join(wood_stone), inline=True)
        if ores:
            embed.add_field(name="Ores & Minerals", value="\n".join(ores), inline=True)
        if plants:
            embed.add_field(name="Plants", value="\n".join(plants), inline=True)
        if other:
            embed.add_field(name="Other Materials", value="\n".join(other), inline=True)
        
        embed.set_footer(text="Use !recipes to see what you can craft")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def use(self, ctx, *, item_name=None):
        """Use a consumable item like a potion"""
        user_id = str(ctx.author.id)
        
        if not player_exists(user_id):
            await ctx.send("You need to start your journey with `!start` first.")
            return
        
        if not item_name:
            await ctx.send("Please specify an item to use. For example: `!use Healing Potion`")
            return
        
        player = get_player(user_id)
        
        # Check if player has the item
        if "inventory" not in player or item_name not in player["inventory"] or player["inventory"].get(item_name, 0) <= 0:
            await ctx.send(f"You don't have any {item_name} in your inventory.")
            return
        
        # Handle different types of usable items
        if item_name == "Healing Potion":
            # Get max HP
            max_hp = 100  # Default
            if "stats" in player and "vitality" in player["stats"]:
                vitality = player["stats"]["vitality"]
                max_hp = 100 + (vitality * 5)  # Assuming vitality gives +5 HP per point
            
            # Apply healing
            old_hp = player["hp"]
            player["hp"] = min(player["hp"] + 50, max_hp)
            healed = player["hp"] - old_hp
            
            # Remove the item
            player["inventory"][item_name] -= 1
            if player["inventory"][item_name] <= 0:
                del player["inventory"][item_name]
            
            update_player(user_id, player)
            await ctx.send(f"You used a Healing Potion and recovered {healed} HP. ({player['hp']}/{max_hp} HP)")
        
        elif item_name == "Stamina Potion":
            # Implement stamina mechanic if it exists
            # For now, just give a small XP boost
            old_xp = player["xp"]
            player["xp"] += 20
            
            # Remove the item
            player["inventory"][item_name] -= 1
            if player["inventory"][item_name] <= 0:
                del player["inventory"][item_name]
            
            update_player(user_id, player)
            await ctx.send(f"You used a Stamina Potion and gained 20 XP! ({old_xp} → {player['xp']} XP)")
        
        else:
            await ctx.send(f"This item cannot be used directly. Some items are used automatically when needed or must be equipped.")

async def setup(bot):
    await bot.add_cog(Crafting(bot))