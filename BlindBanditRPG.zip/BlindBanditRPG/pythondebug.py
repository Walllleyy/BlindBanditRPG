# debug.py
import sys
import os

print("Current working directory:", os.getcwd())
print("Python path:", sys.path)

print("\nTesting imports...")
try:
    import utils.player_utils
    print("✅ utils.player_utils imported")
except Exception as e:
    print(f"❌ utils.player_utils error: {e}")

try:
    import models.player
    print("✅ models.player imported")
except Exception as e:
    print(f"❌ models.player error: {e}")

try:
    import models.classes
    print("✅ models.classes imported")
except Exception as e:
    print(f"❌ models.classes error: {e}")

print("\nTesting specific functions...")
try:
    from models.player import calculate_max_hp
    print("✅ calculate_max_hp imported")
except Exception as e:
    print(f"❌ calculate_max_hp error: {e}")

try:
    from utils.player_utils import check_level_up
    print("✅ check_level_up imported")
except Exception as e:
    print(f"❌ check_level_up error: {e}")