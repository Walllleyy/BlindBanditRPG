import discord
from discord.ext import commands
import os
import asyncio
from dotenv import load_dotenv
from config import COMMAND_PREFIX, DATA_DIR
from utils.player_utils_update import update_player_models

# Load environment variables
load_dotenv()

# Set up intents
intents = discord.Intents.default()
intents.message_content = True

# Create bot instance
bot = commands.Bot(command_prefix=COMMAND_PREFIX, intents=intents)

# Ensure data directory exists
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

@bot.event
async def on_ready():
    print(f"🟢 BlindBanditRPG is live as {bot.user.name}")
    
    # Update player models to support new features
    updated = update_player_models()
    if updated:
        print("📊 Player models updated to support new features.")
    
    # Set bot status
    activity = discord.Game(name=f"Type {COMMAND_PREFIX}start to begin")
    await bot.change_presence(activity=activity)

async def load_extensions():
    """Load all cog extensions"""
    # Load cogs from the cogs directory
    for filename in os.listdir('./cogs'):
        if filename.endswith('.py') and not filename.startswith('__'):
            try:
                await bot.load_extension(f'cogs.{filename[:-3]}')
                print(f"Loaded extension: {filename[:-3]}")
            except Exception as e:
                print(f"Failed to load extension {filename}: {e}")

@bot.event
async def setup_hook():
    """Setup hook that runs before the bot starts"""
    await load_extensions()

# Run the bot
if __name__ == "__main__":
    try:
        bot.run(os.environ["BOT_TOKEN"])
    except KeyError:
        print("Error: BOT_TOKEN environment variable not found.")
        print("Make sure you have a .env file with BOT_TOKEN=your_token")
    except discord.errors.LoginFailure:
        print("Error: Invalid Discord bot token. Please check your token.")
    except Exception as e:
        print(f"Error starting bot: {e}")